# Cinema Mood — партия изображений №5

В этой партии добавлены внешние URL постеров для фильмов 62–71. Файлы изображений не скачаны локально: приложение загружает их по указанным адресам при отображении карточки.

| Фильм | Год | Страница-источник |
|---|---:|---|
| В поисках Немо | 2003 | https://www.impawards.com/2003/finding_nemo_ver2.html |
| Корпорация монстров | 2001 | https://www.impawards.com/2001/monsters_inc_ver1.html |
| Рататуй | 2007 | https://www.impawards.com/2007/ratatouille.html |
| Суперсемейка | 2004 | https://www.impawards.com/2004/incredibles_ver2.html |
| Мстители: Финал | 2019 | https://www.impawards.com/2019/avengers_endgame.html |
| Дюна: Часть вторая | 2024 | https://www.impawards.com/2024/dune_part_two.html |
| Человек-паук: Через вселенные | 2018 | https://www.impawards.com/2018/spiderman_into_the_spiderverse.html |
| Мстители | 2012 | https://www.impawards.com/2012/avengers_ver19.html |
| Логан | 2017 | https://www.impawards.com/2017/logan.html |
| Дэдпул | 2016 | https://www.impawards.com/2016/deadpool.html |

Источники — галереи IMP Awards. Название и год сопоставлены с карточкой фильма. Внешние URL могут быть ограничены политикой хотлинкинга или измениться; поэтому это не гарантирует локальную доступность изображения.
