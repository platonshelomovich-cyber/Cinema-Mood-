# Hollywood batch 02 — 40 films

- 40 additional unique feature films, selected as a curated continuation of the Hollywood catalogue.
- No duplicate original titles against the 45 records in the supplied starting database.
- Each record includes Russian and original titles, year, IMDb-style rating snapshot, genres, synopsis, director, an editorial recommendation, and an interesting fact.
- The import is idempotent: rerunning `python scripts/import_hollywood_batch_02.py` does not create duplicate records.
- Posters, runtime, full cast, age ratings, direct watch links, and verified trailer URLs are not yet populated for this batch. The interface must not present search results as verified playback links.
- Ratings are editorial snapshot values and should be refreshed/verified against the live IMDb chart or TMDB before a public production release.

Import: `python scripts/import_hollywood_batch_02.py`
