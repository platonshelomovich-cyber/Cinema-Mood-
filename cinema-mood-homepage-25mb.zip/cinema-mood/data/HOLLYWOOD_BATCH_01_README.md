# Hollywood batch 01 — 40 films

- 40 unique feature films, curated from the IMDb Top 250 chart data snapshot dated 2026-11-04 (secondary mirror describes its public-data update cadence and notes that it reproduces approximately 90% of the official chart).
- Ratings are the snapshot values, not a promise of a permanent score; they can change.
- IMDb chart source: https://www.imdb.com/chart/top/
- Snapshot/reference: https://4kmonitor.org/en/imdb-top-250
- Film entries include Russian/original titles, year, rating, selected genres, short synopsis, director, and a short editorial recommendation.
- Watch and trailer URLs are intentionally NULL: no direct, rights-holder-approved VK full-film link or verified trailer URL was confirmed for this batch. The site must not present a search query as a verified video.
- Runtime, cast, poster and individual fact citations remain unfilled where they were not verified in this batch. Do not infer them from empty fields.
- The US country/category selection is a catalog classification for this Hollywood batch, not a claim that every film was shot only in the US.

Import (idempotent): `python scripts/import_hollywood_batch_01.py`
