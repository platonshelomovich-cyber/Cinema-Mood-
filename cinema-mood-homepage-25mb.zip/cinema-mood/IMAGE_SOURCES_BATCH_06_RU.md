# Cinema Mood — партия изображений №6

Добавлены ссылки на постеры последних 14 фильмов каталога. Название и год каждого фильма сверены с карточкой галереи IMP Awards. Важно: среда сборки не имеет доступа к внешней сети, поэтому сами JPG не скачаны и прямые URL изображений здесь не удалось проверить запросом. Ссылки на страницы-источники проверены поисковой выдачей; если сайт-источник ограничивает хотлинкинг, изображение может не отобразиться.

| Фильм | Год | Страница-источник |
|---|---:|---|
| Стражи Галактики (Guardians of the Galaxy) | 2014 | https://www.impawards.com/2014/guardians_of_the_galaxy.html |
| Железный человек (Iron Man) | 2008 | https://www.impawards.com/2008/iron_man.html |
| Бегущий по лезвию 2049 (Blade Runner 2049) | 2017 | https://www.impawards.com/2017/blade_runner_twenty_forty_nine.html |
| Безумный Макс: Дорога ярости (Mad Max: Fury Road) | 2015 | https://www.impawards.com/intl/australia/2015/mad_max_fury_road_ver8.html |
| Отель «Гранд Будапешт» (The Grand Budapest Hotel) | 2014 | https://www.impawards.com/2014/grand_budapest_hotel_ver10.html |
| Социальная сеть (The Social Network) | 2010 | https://www.impawards.com/2010/social_network.html |
| Нефть (There Will Be Blood) | 2007 | https://www.impawards.com/2007/there_will_be_blood_ver2.html |
| Старикам тут не место (No Country for Old Men) | 2007 | https://www.impawards.com/2007/no_country_for_old_men.html |
| Игры разума (A Beautiful Mind) | 2001 | https://www.impawards.com/2001/beautiful_mind.html |
| Шестое чувство (The Sixth Sense) | 1999 | https://www.impawards.com/1999/sixth_sense_ver1.html |
| Челюсти (Jaws) | 1975 | https://www.impawards.com/1975/jaws.html |
| Парк юрского периода (Jurassic Park) | 1993 | https://www.impawards.com/1993/jurassic_park_ver1.html |
| Поймай меня, если сможешь (Catch Me If You Can) | 2002 | https://www.impawards.com/2002/catch_me_if_you_can.html |
| Остров проклятых (Shutter Island) | 2010 | https://www.impawards.com/2010/shutter_island.html |
