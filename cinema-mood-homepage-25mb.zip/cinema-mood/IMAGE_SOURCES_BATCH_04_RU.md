# Источники изображений — партия №4

Для каждого фильма ниже найден отдельный постер на IMP Awards; совпадение проверено по названию и году, а страница-источник приведена рядом. В базе сохранены внешние URL изображений, сами файлы пока не скачаны локально.

- **Амадей (1984)** — IMP Awards — Amadeus (1984)
  - Изображение: https://www.impawards.com/1984/posters/amadeus_ver1.jpg
  - Источник: https://www.impawards.com/1984/amadeus_ver1.html
- **ВАЛЛ·И (2008)** — IMP Awards — WALL·E (2008)
  - Изображение: https://www.impawards.com/2008/posters/wall_e_ver11.jpg
  - Источник: https://www.impawards.com/2008/wall_e_ver11.html
- **Чужие (1986)** — IMP Awards — Aliens (1986)
  - Изображение: https://www.impawards.com/1986/posters/aliens_ver1.jpg
  - Источник: https://www.impawards.com/1986/aliens_ver1.html
- **Волк с Уолл-стрит (2013)** — IMP Awards — The Wolf of Wall Street (2013)
  - Изображение: https://www.impawards.com/2013/posters/wolf_of_wall_street_ver7.jpg
  - Источник: https://www.impawards.com/2013/wolf_of_wall_street_ver7.html
- **Шоу Трумана (1998)** — IMP Awards — The Truman Show (1998)
  - Изображение: https://www.impawards.com/1998/posters/truman_show_ver1.jpg
  - Источник: https://www.impawards.com/1998/truman_show_ver1.html
- **Вечное сияние чистого разума (2004)** — IMP Awards — Eternal Sunshine of the Spotless Mind (2004)
  - Изображение: https://www.impawards.com/2004/posters/eternal_sunshine_of_the_spotless_mind_ver1.jpg
  - Источник: https://www.impawards.com/2004/eternal_sunshine_of_the_spotless_mind_ver1.html
- **История игрушек (1995)** — IMP Awards — Toy Story (1995)
  - Изображение: https://www.impawards.com/1995/posters/toy_story_ver1.jpg
  - Источник: https://www.impawards.com/1995/toy_story_ver1.html
- **История игрушек: Большой побег (2010)** — IMP Awards — Toy Story 3 (2010)
  - Изображение: https://www.impawards.com/2010/posters/toy_story_three_ver1.jpg
  - Источник: https://www.impawards.com/2010/toy_story_three.html
- **Вверх (2009)** — IMP Awards — Up (2009)
  - Изображение: https://www.impawards.com/2009/posters/up.jpg
  - Источник: https://www.impawards.com/2009/up.html
- **Головоломка (2015)** — IMP Awards — Inside Out (2015)
  - Изображение: https://www.impawards.com/2015/posters/inside_out_ver13.jpg
  - Источник: https://www.impawards.com/2015/inside_out_ver13.html

**Итого в базе:** 61 из 85 фильмов имеют ссылку на изображение. Файлы изображений остаются внешними URL.
