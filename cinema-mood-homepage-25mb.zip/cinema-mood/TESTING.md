# Acceptance checklist

Run after `docker compose up --build`, configure API credentials, and import the curated data.

- [ ] `GET /api/health` returns status `ok`.
- [ ] `GET /api/catalog/status` reports exactly 1,900 records and category quotas 1,300 / 570 / 30.
- [ ] `python scripts/verify_catalog.py` passes.
- [x] Register adult account on an isolated copy of the 85-film database; log out; log in again; profile remains (HTTP/API test).
- [ ] Repeat registration/login in a real browser after installing dependencies in the deployment environment.
- [ ] Register account with age <=10; `GET /api/me` reports child_mode true.
- [ ] A child cannot set a parent PIN without the separate `PARENT_SETUP_TOKEN`.
- [ ] Wrong parent PIN is rejected; correct PIN grants a 30-minute server-side override that survives refresh.
- [ ] Catalogue, sections, weekly pick, surprise, details, favourites, history, and AI remain age-filtered for child profiles.
- [ ] Catalog filters and sorting operate against the full database.
- [ ] First page returns up to 40 rows; next page uses offset=40 without duplicates for the same seed.
- [ ] Surprise selects from all eligible database rows and avoids recent picks.
- [ ] Weekly pick remains identical for repeated calls in the same week and audience type.
- [ ] AI results contain only database film IDs and exclude unsafe child-profile rows.
- [ ] Favourite/history/review state survives a new login.
- [ ] Non-admin receives HTTP 403 from `/api/admin/*`.
- [ ] Pending reviews and suggestions are visible to admins only.
- [ ] Oscar badges appear only when verified award import populated `oscar_wins`.
- [ ] Test VK ID / Yandex ID only after their OAuth applications and callback URLs are configured.

## Manual media metadata update

The Film model and SQLite database now persist `watch_url`, `trailer_url`, `source_url`, `interesting_fact`, `fact_source_url`, and `why_watch`. The pilot import writes these fields, and the film detail API returns them. The detail page displays saved direct links when present; otherwise it clearly labels fallback links as search results. The five existing pilot records were migrated from `data/manual_pilot_films.json`.

Checks run for this update:
- Python compileall for `app` and `scripts`.
- Node syntax check for `app/static/film.js`.
- SQLite count and field verification: 5 total records; 5 have saved watch and trailer URLs; 5 have interesting facts.

The 40-film Hollywood batch has not yet been imported.

## Second Hollywood batch

- [x] Starting database contains 45 records (40 Hollywood + 5 Soviet).
- [x] Batch 02 contains exactly 40 unique additional films.
- [x] Batch 02 importer ran idempotently and inserted 40 records; total database count is 85.
- [x] All 85 rows have unique internal TMDB placeholder IDs; ratings are within 7.0–10.0; titles, years, directors, synopses and recommendation fields are present.
- [x] Local API smoke tests and adult registration/login were completed using PyJWT + Argon2 on an isolated database copy.
- [ ] Browser interaction tests and public deployment remain pending; the execution environment has no installed browser binary and production credentials/hosting are not configured.
