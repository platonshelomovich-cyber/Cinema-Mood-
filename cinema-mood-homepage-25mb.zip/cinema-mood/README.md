# Cinema Mood — адаптивный сайт

Cinema Mood is a browser-based, responsive website built with FastAPI, HTML, CSS, JavaScript and PostgreSQL (SQLite fallback for local development). It is not a native Android or iOS application. The same site layout adapts to desktop, tablet and mobile screens.

## Запуск перенесённого проекта без API-ключей

Это перенос существующего проекта Cinema Mood в отдельную папку. Ничего от пользователя для переноса не требуется. Для локального запуска каталога и интерфейса ключи TMDB, Яндекса, VK и OpenAI не нужны. Эти интеграции остаются необязательными и без ключей не активируются.

1. Установить Python 3.11 или новее.
2. В терминале из этой папки выполнить `python -m venv .venv`, активировать окружение и установить зависимости: `pip install -r requirements.txt`.
3. Запустить сайт: `uvicorn app.main:app --host 127.0.0.1 --port 8000`.
4. Открыть `http://127.0.0.1:8000`.

При первом запуске приложение создаёт таблицы SQLite. В архив уже включена база `cinema_mood.db` с каталогом из 85 фильмов.

## Included in this build

- PostgreSQL persistence (SQLite fallback for local development).
- Email/password registration and login; HttpOnly session cookie.
- Date-of-birth age calculation and child-profile content filtering on server endpoints.
- Argon2 password and parent-PIN hashing.
- Film catalog API with server-side filters, sorting and pagination.
- Random recommendation endpoint with server-side per-user recent-history exclusion.
- Weekly pick persisted by week start and audience type.
- AI recommendation route: OpenAI ranking of eligible database records when `OPENAI_API_KEY` is configured; lexical fallback otherwise.
- Favorites, watch history, profile statistics, review submission/edit/delete/moderation, film suggestions, TMDB trailer lookup, and protected admin moderation endpoints.
- Responsive black/orange website interface for desktop, tablet and mobile browsers.

## Important production work still required

This package is an executable foundation, not a deployed production service and not a claim that the 1,900-film import has already succeeded.

- **TMDB import:** run `python scripts/import_tmdb.py` after setting `TMDB_API_KEY`. The script refuses to commit unless it can verify exactly 1,300 US-production, 570 eligible non-US/non-African/non-South-Korean world films, and 30 Soviet films, with unique TMDB IDs and ratings >= 7.0. TMDB availability and country metadata can prevent the quotas from being met; broaden/review curation rules rather than silently fabricating records.
- **Oscar data:** populate `data/oscars.csv` from a licensed/verified awards source and run `python scripts/import_oscars.py`. TMDB is not a complete authoritative Oscar-awards database. No awards are fabricated in this starter.
- **Child safety:** `CHILD_ALLOWED` is intentionally conservative (G, TV-Y, TV-Y7 only). Configure a unique `PARENT_SETUP_TOKEN` out of band; a parent must use it to establish or recover a hashed PIN. The PIN grants a 30-minute server-side override and is not stored in browser state. A production release still needs verified guardian identity/consent, market-specific age-rating review, parental account/recovery workflow, content audits, and legal review.
- **OAuth:** VK ID and Yandex ID require registered applications, redirect URIs, client secrets, callback validation, account-linking rules and provider-specific implementation. They are not represented as enabled until configured.
- **Uploads:** avatar and poster uploads need object storage, file-type/size validation, malware scanning and signed URLs.
- **Hardening:** set `secure=True` cookies behind HTTPS, add CSRF protection, rate limits, email verification, password reset, audit logs, database migrations (Alembic), backups, monitoring, privacy/retention policy, and automated tests before public launch.
- **Admin bootstrap:** first account matching `ADMIN_EMAIL` is marked admin. Set this to a controlled address before first registration; do not expose public sign-up to that address. Keep `PARENT_SETUP_TOKEN` separate from `SECRET_KEY` and do not share it with children.
- **AI scale:** current OpenAI route batches the eligible database into chunks and ranks IDs. For production, use PostgreSQL full-text + pgvector hybrid retrieval and add token/cost limits, caching, prompt-injection defenses, and evaluation tests.
- **Weekly selection:** first request for each week creates a shared pick, persists it, and avoids the previous eight weekly picks where possible. For deterministic Monday publishing, add a scheduler/cron job.
- **Browser tests:** run API and UI tests against a populated staging DB. This environment cannot deploy the service or verify external credentials.

## Useful endpoints

- `GET /api/health`, `GET /api/catalog/status`
- `POST /api/auth/register`, `POST /api/auth/login`, `POST /api/auth/logout`
- `GET /api/me`, `PATCH /api/me`, `GET /api/me/stats`, `GET /api/me/reviews`
- `GET /api/films`, `GET /api/films/sections`, `GET /api/films/{id}`, `GET /api/films/{id}/trailer`
- `POST /api/ai/recommend?prompt=...`
- `GET /api/surprise`, `GET /api/weekly`
- `POST /api/films/{id}/favorite`, `POST /api/films/{id}/watched`
- `GET /api/me/favorites`, `GET /api/me/history`
- `POST /api/films/{id}/reviews`, `POST /api/suggestions`
- `GET /api/admin/overview`, `GET /api/admin/reviews`, `POST /api/admin/reviews/{id}/approve`

## TMDB attribution

Если используются данные или изображения TMDB, необходимо соблюдать правила атрибуции и условия TMDB. Локальный каталог может запускаться без TMDB API-ключа.


## Интернет-поиск, трейлеры и просмотр

- Карточка фильма предоставляет внешние поисковые ссылки на Яндекс, Google и Bing, поиск трейлеров в VK Видео и YouTube, а также отдельную выдачу публичных видео VK через VK API при настроенном токене.
- Ссылки на просмотр выделены отдельно: JustWatch используется как справочник легальных предложений в выбранном регионе; поиск VK Видео помечен как поиск публикаций правообладателей — открывать следует только официальные/лицензированные загрузки.
- Для настоящего серверного поиска по всему интернету добавьте `YANDEX_SEARCH_API_KEY` и `YANDEX_FOLDER_ID`. Используется Yandex Search API (`https://searchapi.api.cloud.yandex.net/v2/web/search`), семейный фильтр для детского профиля включён на стороне запроса.
- `VK_ACCESS_TOKEN` включает серверный поиск публичных роликов VK Video (при наличии необходимых прав токена); без него работает прямая поисковая ссылка VK. `WATCH_REGION` задаёт регион доступности (по умолчанию CA). Доступность зависит от лицензий и страны.
- Cinema Mood не скачивает и не проксирует защищённые авторским правом фильмы. Сервис показывает только ссылки на официальные источники и внешние результаты поиска; правомерность конкретной загрузки проверяется у площадки/правообладателя.

См. документацию: https://aistudio.yandex.ru/ru/docs/search-api/api-ref/WebSearch/search и https://www.justwatch.com/ca/JustWatch-Streaming-API.


## Download missing posters for existing catalogue

Set `TMDB_API_KEY` (TMDB v3 API key) and run `python scripts/download_missing_posters.py`. The script searches by original title and release year, downloads only a matching result with a poster, stores the image in `app/static/posters/`, and updates only the poster field. It does not create or delete films. Check TMDB attribution and image-use terms before public deployment.


## Без ключей: поиск недостающих изображений

Запустите `python scripts/download_missing_posters.py`. Скрипт использует публичный API Wikipedia/MediaWiki без API-ключа, ищет статью фильма и скачивает только портретную главную картинку подходящего размера. Это не гарантирует, что найден именно официальный постер: фильм может остаться без изображения. Проверяйте подписи и лицензию каждого файла перед публикацией; API возвращает страницу-источник в `source_url`.

## Изображения каталога (добавлено 7 ноября 2026)

В `data/images_manifest.json` хранится реестр найденных изображений: фильм, тип изображения, прямая ссылка и страница-источник. В текущей версии добавлены 31 проверенная ссылка на постеры из 85 карточек. Изображения пока подключены по внешним URL и не включены в архив как локальные файлы: среда подготовки не смогла скачать их с внешних серверов. Для остальных фильмов не подставляются случайные изображения.

В карточках предусмотрено поле `image_kind`: `poster` для постера и `still` для кадра из фильма. Для `still` интерфейс показывает подпись «Кадр из фильма». Внешние `http(s)`-адреса поддерживаются наряду с локальными `/static/...` файлами и TMDB-путями.

Для локального скачивания изображений в среде, где доступен интернет, предусмотрен скрипт `python scripts/download_catalog_images.py`. Он скачивает доступные файлы в `app/static/posters/`, проверяет MIME-тип и обновляет `poster_path` на локальный путь; если источник недоступен, запись остаётся внешней ссылкой.

Права на изображения и условия повторного использования зависят от конкретного источника. Перед публичным или коммерческим запуском проверьте лицензии/разрешения и при необходимости замените изображения на разрешённые материалы.


## Доступ к каталогу: витрина и расширенная библиотека

- Первые 85 фильмов сохранены как открытая витрина (`access_level=public`).
- Расширенные фильмы можно добавлять с `access_level=member`: они будут видны только после входа в аккаунт.
- Это одна общая база фильмов, а не отдельные копии для каждого пользователя. Для каждого пользователя выдача может перемешиваться своим seed; фильтры по жанрам, странам, годам, рейтингу, режиссёрам и актёрам остаются общими.
- Избранное, отзывы и история просмотра продолжают ссылаться на единый `film_id`, поэтому не теряются при расширении каталога.
- Важно: в текущей поставке по-прежнему 85 записей, а не 1900. Расширенная схема доступа подготовлена, но остальные фильмы ещё нужно наполнить и проверить.

## Проверка ссылок на постеры

Чтобы проверить внешние изображения всех фильмов, запустите из корня проекта:

```bash
python scripts/check_image_links.py
```

Скрипт проверит URL из `cinema_mood.db` и создаст `data/image_link_check.csv`. Статус «РАБОТАЕТ» означает, что источник вернул изображение; «НЕ РАБОТАЕТ» или «ПРОВЕРИТЬ» требует замены/ручной проверки. «ОШИБКА СЕТИ» может быть вызвана блокировкой сайта или отсутствием соединения.

## Глобальный поиск фильмов

В разделе «Каталог» есть отдельный поиск по международной базе TMDB. Он ищет фильмы вне стартовых 85, показывает найденные данные и постеры, но **не добавляет результаты в постоянную базу автоматически**. Для гостей результаты вне доступного каталога затемняются и отмечаются замком; зарегистрированные пользователи могут просматривать найденную информацию. Фильмы, уже входящие в доступный каталог, открываются как обычные карточки.

Для работы поиска администратор должен указать `TMDB_API_KEY` в переменных окружения/файле `.env` на сервере. Без ключа сайт продолжает работать, но глобальный поиск сообщает, что интеграция не настроена. Ключ хранится только на сервере и не передаётся браузеру. Источник поиска — TMDB; это поиск по мировой кинобазе, а не обещание найти абсолютно каждый фильм, когда-либо снятый.


## Поиск фильмов без API-ключей

Глобальный поиск использует публичные MediaWiki API русской и английской Википедии. Ключи TMDB, Яндекса и OpenAI для этого поиска не нужны. Результаты являются временными, не добавляются в базу автоматически; изображения и метаданные зависят от наличия статьи и должны проверяться. Это не полный мировой каталог фильмов. Публичные сервисы могут ограничивать частоту запросов или временно быть недоступны.

## Обложки и расширение каталога

- В `app/static/posters/` находятся 1000 локальных оригинальных графических обложек Cinema Mood. Это не официальные кинопостеры и не кадры из фильмов.
- Для пересоздания обложек после импорта запустите `python scripts/generate_cinema_art.py --all`.
- Чтобы добавить до 900 дополнительных реальных названий без API-ключа, запустите `python scripts/import_wikidata_900.py`, затем `python scripts/generate_cinema_art.py --all`. Импорт требует доступ к Wikidata Query Service и может быть ограничен доступностью сервиса.
- Новые записи будут помечены как требующие редакционной проверки и будут доступны участникам; непроверенные возрастные рейтинги остаются `NR`.
- В гостевом каталоге по-прежнему 85 фильмов; полный текущий локальный каталог содержит 1000 записей.
