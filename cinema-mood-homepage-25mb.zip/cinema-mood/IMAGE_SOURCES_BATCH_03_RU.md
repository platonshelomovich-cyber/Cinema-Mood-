# Источники изображений — партия №3

В этой партии добавлены ссылки на постеры для 10 фильмов. Ссылки ведут к прямому изображению; страницы-источники приведены для проверки. Для двух изображений Wikimedia Commons в описании файла указана лицензия/статус, но права могут различаться по странам — проверяйте условия перед коммерческим использованием.

- **Terminator 2: Judgment Day (1991) — IMP Awards**
  - Изображение: https://www.impawards.com/1991/posters/terminator_two_judgement_day.jpg
  - Источник: https://www.impawards.com/1991/terminator_two_judgement_day.html
- **Django Unchained (2012) — IMP Awards**
  - Изображение: https://www.impawards.com/2012/posters/django_unchained.jpg
  - Источник: https://www.impawards.com/2012/django_unchained.html
- **Psycho (1960) — Wikimedia Commons**
  - Изображение: https://upload.wikimedia.org/wikipedia/commons/5/52/Psycho_%281960%29_theatrical_poster.jpg
  - Источник: https://commons.wikimedia.org/wiki/File:Psycho_(1960)_theatrical_poster.jpg
- **Inglourious Basterds (2009) — IMP Awards**
  - Изображение: https://www.impawards.com/2009/posters/inglourious_basterds.jpg
  - Источник: https://www.impawards.com/2009/inglourious_basterds.html
- **Memento (2000; poster listing 2001) — IMP Awards**
  - Изображение: https://www.impawards.com/2001/posters/memento.jpg
  - Источник: https://www.impawards.com/2001/memento.html
- **Apocalypse Now (1979) — IMP Awards**
  - Изображение: https://www.impawards.com/1979/posters/apocalypse_now_ver1.jpg
  - Источник: https://www.impawards.com/1979/apocalypse_now_ver1.html
- **Rear Window (1954) — Wikimedia Commons**
  - Изображение: https://upload.wikimedia.org/wikipedia/commons/3/3a/Rear_Window_film_poster.jpg
  - Источник: https://commons.wikimedia.org/wiki/File:Rear_Window_film_poster.jpg
- **Joker (2019) — IMP Awards**
  - Изображение: https://www.impawards.com/2019/posters/joker.jpg
  - Источник: https://www.impawards.com/2019/joker.html
- **The Professional / Léon (1994) — IMP Awards**
  - Изображение: https://www.impawards.com/1994/posters/professional_ver1.jpg
  - Источник: https://www.impawards.com/1994/professional_ver1.html
- **Coco (2017) — IMP Awards**
  - Изображение: https://www.impawards.com/2017/posters/coco_ver10.jpg
  - Источник: https://www.impawards.com/2017/coco_ver10.html

**Итого в базе:** 51 из 85 фильмов имеют ссылку на изображение после этой партии. Изображения остаются внешними URL; файлы постеров не скачаны в локальную папку проекта.