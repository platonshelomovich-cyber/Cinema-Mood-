from sqlalchemy import select, or_, func, cast, String
from random import Random
from sqlalchemy.orm import Session
from app.models import Film

# Conservative baseline for a child profile. Ratings must also be confirmed by a
# parent/editor; a rating label alone is not a universal content-safety guarantee.
CHILD_ALLOWED = {"G", "TV-Y", "TV-Y7"}
COUNTRY_NAMES = {"US":"США", "GB":"Великобритания", "CA":"Канада", "FR":"Франция", "DE":"Германия", "IT":"Италия", "ES":"Испания", "JP":"Япония", "CN":"Китай", "IN":"Индия", "SU":"СССР", "RU":"Россия", "AU":"Австралия", "NZ":"Новая Зеландия", "BR":"Бразилия", "MX":"Мексика", "AR":"Аргентина", "SE":"Швеция", "NO":"Норвегия", "DK":"Дания", "FI":"Финляндия", "NL":"Нидерланды", "BE":"Бельгия", "CH":"Швейцария", "AT":"Австрия", "PL":"Польша", "CZ":"Чехия", "HU":"Венгрия", "IE":"Ирландия", "IL":"Израиль", "TR":"Турция", "IR":"Иран", "HK":"Гонконг", "TW":"Тайвань", "TH":"Таиланд", "ID":"Индонезия", "PH":"Филиппины", "SG":"Сингапур"}
COUNTRY_CODES = {v.casefold(): k for k, v in COUNTRY_NAMES.items()}
COUNTRY_CODES.update({"usa":"US", "united states":"US", "united states of america":"US", "uk":"GB", "u.k.":"GB", "south korea":"KR", "republic of korea":"KR"})

def visible_films(db: Session, child: bool, member: bool = False):
    # The original 85-film showcase stays public. Extended catalogue entries
    # are available to authenticated members without duplicating film records.
    q = select(Film)  # Do not hide unrated/pending films from the base catalogue.
    if not member:
        q = q.where(Film.access_level == "public")
    if child:
        q = q.where(Film.age_rating.in_(CHILD_ALLOWED))
    return q

def film_dict(f: Film):
    return {
        "id": f.id, "tmdb_id": f.tmdb_id, "title": f.title_ru, "access_level": getattr(f, "access_level", "public"),
        "original_title": f.title_original, "year": f.release_year,
        "countries": [COUNTRY_NAMES.get(c, c) for c in (f.countries or [])], "genres": f.genres or [],
        "rating": f.rating, "rating_verified": getattr(f, "interesting_fact", "") != "__metadata_pending__", "image_kind": getattr(f, "image_kind", "poster"), "poster": (f.poster_path if f.poster_path and (f.poster_path.startswith("/static/") or f.poster_path.startswith("https://") or f.poster_path.startswith("http://")) else ("https://image.tmdb.org/t/p/w500" + f.poster_path if f.poster_path else None)),
        "overview": f.overview, "runtime": f.runtime, "director": f.director,
        "cast": f.cast or [], "age_rating": f.age_rating, "oscar_wins": f.oscar_wins,
        "oscar_nominations": f.oscar_nominations, "oscar_years": f.oscar_years or [],
        "category": f.category, "popularity": f.popularity,
        "watch_url": getattr(f, "watch_url", None), "trailer_url": getattr(f, "trailer_url", None),
        "source_url": getattr(f, "source_url", None), "interesting_fact": getattr(f, "interesting_fact", ""),
        "fact_source_url": getattr(f, "fact_source_url", None), "why_watch": getattr(f, "why_watch", "")
    }

def search_films(db: Session, q: str = "", genre: str = "", country: str = "",
                 year_from: int | None = None, year_to: int | None = None,
                 min_rating: float = 0, min_oscars: int | None = None,
                 sort: str = "random", offset: int = 0, limit: int = 40, child: bool = False, seed: str = "cinema-mood", member: bool = False):
    stmt = visible_films(db, child, member=member)
    if q:
        like = f"%{q.strip()}%"
        stmt = stmt.where(or_(Film.title_ru.ilike(like), Film.title_original.ilike(like),
                              Film.director.ilike(like), cast(Film.cast, String).ilike(like)))
    if genre:
        stmt = stmt.where(cast(Film.genres, String).ilike(f'%"{genre}"%'))
    if country:
        normalized_country = COUNTRY_CODES.get(country.strip().casefold(), country.strip().upper())
        stmt = stmt.where(cast(Film.countries, String).ilike(f'%"{normalized_country}"%'))
    if year_from is not None: stmt = stmt.where(Film.release_year >= year_from)
    if year_to is not None: stmt = stmt.where(Film.release_year <= year_to)
    if min_rating > 0:
        stmt = stmt.where(Film.rating >= min_rating)
    if min_oscars is not None: stmt = stmt.where(Film.oscar_wins >= min_oscars)
    if sort == "rating": stmt = stmt.order_by(Film.rating.desc(), Film.popularity.desc())
    elif sort == "year": stmt = stmt.order_by(Film.release_year.desc())
    elif sort == "popular": stmt = stmt.order_by(Film.popularity.desc())
    elif sort == "oscars": stmt = stmt.order_by(Film.oscar_wins.desc(), Film.rating.desc())
    else:
        # Deterministic shuffle per catalogue session. The same seed preserves
        # ordering across 40-item pages; a new seed creates a fresh collection.
        all_rows = db.scalars(stmt).all()
        Random(seed).shuffle(all_rows)
        total = len(all_rows)
        films = all_rows[offset:offset + min(limit, 100)]
        return {"items": [film_dict(f) for f in films], "total": total, "offset": offset, "limit": limit}
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    films = db.scalars(stmt.offset(offset).limit(min(limit, 100))).all()
    return {"items": [film_dict(f) for f in films], "total": total, "offset": offset, "limit": limit}

def child_age_ok(film: Film) -> bool:
    return film.age_rating in CHILD_ALLOWED
