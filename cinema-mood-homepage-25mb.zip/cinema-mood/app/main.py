from datetime import date, datetime, timedelta
from pathlib import Path
from random import choice
import re
from typing import Optional
from urllib.parse import quote_plus, urlencode
from fastapi import FastAPI, Depends, HTTPException, Request, Response, Query
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import select, func, delete, or_, inspect, text
from sqlalchemy.orm import Session
from app.db import Base, engine, get_db
from app.models import User, Film, Favorite, WatchHistory, Review, FilmSuggestion, WeeklyPick, Report, SurpriseHistory
from app.security import hash_secret, verify_secret, issue_token, current_user, optional_user, admin_user, age_years, is_child, assert_parent_pin
from app.catalog import search_films, film_dict, visible_films, child_age_ok
from app.config import settings

if settings.database_url.startswith("postgresql"):
    if len(settings.secret_key) < 32 or "replace-with" in settings.secret_key:
        raise RuntimeError("Set a unique SECRET_KEY (32+ characters) before starting Cinema Mood with PostgreSQL")
    if len(settings.parent_setup_token) < 24 or "replace-with" in settings.parent_setup_token:
        raise RuntimeError("Set a separate PARENT_SETUP_TOKEN (24+ characters) before starting Cinema Mood with PostgreSQL")
    if settings.public_base_url.startswith("https://") and not settings.cookie_secure:
        raise RuntimeError("Set COOKIE_SECURE=true when PUBLIC_BASE_URL uses HTTPS")
Base.metadata.create_all(bind=engine)
# Safe additive migration for databases created before member catalogue tiers.
with engine.begin() as _conn:
    _cols = {c["name"] for c in inspect(engine).get_columns("films")}
    if "access_level" not in _cols:
        _conn.execute(text("ALTER TABLE films ADD COLUMN access_level VARCHAR(20) NOT NULL DEFAULT 'public'"))
        _conn.execute(text("CREATE INDEX IF NOT EXISTS ix_films_access_level ON films (access_level)"))
app = FastAPI(title="Cinema Mood API", version="1.0.0")
APP_DIR = Path(__file__).resolve().parent
app.mount("/static", StaticFiles(directory=str(APP_DIR / "static")), name="static")
templates = Jinja2Templates(directory=str(APP_DIR / "templates"))


def film_access_ok(film: Film, user: User | None) -> bool:
    return getattr(film, "access_level", "public") == "public" or user is not None

class RegisterIn(BaseModel):
    username: str = Field(min_length=3, max_length=40)
    email: EmailStr
    password: str = Field(min_length=10, max_length=128)
    birth_date: date

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class PinSetupIn(BaseModel):
    pin: str = Field(min_length=6, max_length=12)
    setup_token: str = Field(min_length=12, max_length=256)

class PinVerifyIn(BaseModel):
    pin: str = Field(min_length=6, max_length=12)

class ProfileUpdateIn(BaseModel):
    username: str = Field(min_length=3, max_length=40)
    avatar_url: str | None = Field(default=None, max_length=1000)

class ReviewIn(BaseModel):
    score: int = Field(ge=1, le=10)
    body: str = Field(min_length=5, max_length=3000)

class SuggestIn(BaseModel):
    title: str = Field(min_length=1, max_length=300)
    release_year: Optional[int] = Field(default=None, ge=1888, le=2100)
    country: str = Field(default="", max_length=100)
    genre: str = Field(default="", max_length=100)
    description: str = Field(default="", max_length=3000)
    poster_url: str = Field(default="", max_length=1000)

class FilmAdminUpdateIn(BaseModel):
    title_ru: str | None = Field(default=None, min_length=1, max_length=300)
    title_original: str | None = Field(default=None, min_length=1, max_length=300)
    release_year: int | None = Field(default=None, ge=1888, le=2100)
    rating: float | None = Field(default=None, ge=7.0, le=10.0)
    countries: list[str] | None = None
    genres: list[str] | None = None
    poster_path: str | None = Field(default=None, max_length=500)
    overview: str | None = Field(default=None, max_length=10000)
    runtime: int | None = Field(default=None, ge=1, le=1000)
    director: str | None = Field(default=None, max_length=300)
    cast: list[str] | None = None
    age_rating: str | None = Field(default=None, max_length=20)
    oscar_wins: int | None = Field(default=None, ge=0, le=30)
    oscar_nominations: int | None = Field(default=None, ge=0, le=100)
    oscar_years: list[int] | None = None
    category: str | None = None

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/api/health")
def health(db: Session = Depends(get_db)):
    return {"status": "ok", "films": db.scalar(select(func.count(Film.id))) or 0}

@app.get("/api/catalog/status")
def catalog_status(db: Session = Depends(get_db)):
    total = db.scalar(select(func.count(Film.id))) or 0
    counts = {name: db.scalar(select(func.count(Film.id)).where(Film.category == name)) or 0 for name in ("hollywood", "world", "soviet")}
    expected = {"hollywood": 1300, "world": 570, "soviet": 30}
    public_total = db.scalar(select(func.count(Film.id)).where(Film.access_level == "public")) or 0
    member_total = db.scalar(select(func.count(Film.id)).where(Film.access_level == "member")) or 0
    return {"ready": total == 1900 and counts == expected, "total": total, "expected_total": 1900,
            "stage_500_ready": total >= 500, "stage_total": 500,
            "public_films": public_total, "member_films": member_total,
            "categories": counts, "expected_categories": expected}

@app.post("/api/auth/register")
def register(data: RegisterIn, response: Response, db: Session = Depends(get_db)):
    if data.birth_date >= date.today():
        raise HTTPException(400, "Укажите корректную дату рождения")
    if db.scalar(select(User).where((User.email == data.email) | (User.username == data.username))):
        raise HTTPException(409, "Email или имя пользователя уже заняты")
    user = User(username=data.username, email=data.email, password_hash=hash_secret(data.password),
                birth_date=data.birth_date, is_admin=False)
    db.add(user); db.commit(); db.refresh(user)
    response.set_cookie("cm_session", issue_token(user), httponly=True, secure=settings.cookie_secure,
                        samesite="lax", max_age=7*24*3600)
    return {"ok": True, "user": {"id": user.id, "username": user.username,
            "child_mode": is_child(user), "age": age_years(user.birth_date)}}

@app.post("/api/auth/login")
def login(data: LoginIn, response: Response, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == data.email))
    if not user or not verify_secret(data.password, user.password_hash):
        raise HTTPException(401, "Неверный email или пароль")
    response.set_cookie("cm_session", issue_token(user), httponly=True, secure=settings.cookie_secure,
                        samesite="lax", max_age=7*24*3600)
    return {"ok": True, "user": {"id": user.id, "username": user.username,
            "child_mode": is_child(user), "age": age_years(user.birth_date)}}

@app.post("/api/auth/logout")
def logout(response: Response):
    response.delete_cookie("cm_session")
    return {"ok": True}

@app.get("/api/me")
def me(user: User = Depends(current_user), db: Session = Depends(get_db)):
    favorites = db.scalar(select(func.count(Favorite.id)).where(Favorite.user_id == user.id)) or 0
    watched = db.scalar(select(func.count(WatchHistory.id)).where(WatchHistory.user_id == user.id)) or 0
    reviews = db.scalar(select(func.count(Review.id)).where(Review.user_id == user.id)) or 0
    return {"id": user.id, "username": user.username, "email": user.email,
            "age": age_years(user.birth_date), "child_mode": is_child(user),
            "created_at": user.created_at.isoformat(), "favorites": favorites,
            "watched": watched, "reviews": reviews, "avatar_url": user.avatar_url,
            "is_admin": user.is_admin, "parent_pin_set": bool(user.parent_pin_hash)}

@app.patch("/api/me")
def update_profile(data: ProfileUpdateIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    existing = db.scalar(select(User).where(User.username == data.username, User.id != user.id))
    if existing: raise HTTPException(409, "Имя пользователя уже занято")
    normalized_username = data.username.strip()
    if len(normalized_username) < 3:
        raise HTTPException(422, "Имя пользователя должно содержать минимум 3 символа")
    user.username = normalized_username
    if data.avatar_url is not None:
        # Only HTTPS image URLs are accepted; direct file uploads need object storage.
        if data.avatar_url and not data.avatar_url.startswith("https://"):
            raise HTTPException(422, "Аватар должен быть доступен по HTTPS")
        user.avatar_url = data.avatar_url or None
    db.commit()
    return {"ok": True, "username": user.username, "avatar_url": user.avatar_url}

@app.get("/api/me/stats")
def profile_stats(user: User = Depends(current_user), db: Session = Depends(get_db)):
    watched_rows = db.scalars(select(WatchHistory).where(WatchHistory.user_id == user.id)).all()
    film_ids = [r.film_id for r in watched_rows]
    watched_films = db.scalars(select(Film).where(Film.id.in_(film_ids))).all() if film_ids else []
    genre_counts = {}
    for film in watched_films:
        if is_child(user) and not child_age_ok(film):
            continue
        for genre in film.genres or []:
            genre_counts[genre] = genre_counts.get(genre, 0) + 1
    scores = db.scalars(select(Review.score).where(Review.user_id == user.id)).all()
    return {"average_score": round(sum(scores) / len(scores), 1) if scores else None,
            "favorite_genres": sorted(genre_counts.items(), key=lambda x: x[1], reverse=True)[:5],
            "most_watched_genre": max(genre_counts, key=genre_counts.get) if genre_counts else None}

@app.delete("/api/me/favorites/{film_id}")
def remove_favorite(film_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    row = db.scalar(select(Favorite).where(Favorite.user_id == user.id, Favorite.film_id == film_id))
    if row:
        db.delete(row); db.commit()
    return {"ok": True}

@app.get("/api/me/reviews")
def my_reviews(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.scalars(select(Review).where(Review.user_id == user.id).order_by(Review.updated_at.desc())).all()
    return [{"id": r.id, "film_id": r.film_id, "film_title": db.get(Film, r.film_id).title_ru if db.get(Film, r.film_id) else "Фильм удалён",
             "score": r.score, "body": r.body, "status": r.status, "created_at": r.created_at.isoformat()} for r in rows]

@app.post("/api/parent/pin")
def set_pin(data: PinSetupIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if not is_child(user):
        raise HTTPException(400, "Родительский PIN нужен только детскому профилю")
    if not settings.parent_setup_token or not __import__("hmac").compare_digest(data.setup_token, settings.parent_setup_token):
        raise HTTPException(403, "Для настройки PIN требуется подтверждение родителя")
    user.parent_pin_hash = hash_secret(data.pin)
    db.commit()
    return {"ok": True}

@app.post("/api/parent/exit-child-mode")
def exit_child_mode(data: PinVerifyIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if not is_child(user):
        return {"ok": True, "child_mode": False}
    assert_parent_pin(user, data.pin)
    user.guardian_verified_until = datetime.utcnow() + timedelta(minutes=30)
    db.commit()
    # The override lives in the database, so refreshing or logging in again
    # does not erase it; it expires automatically and the child filter returns.
    return {"ok": True, "guardian_verified": True, "expires_at": user.guardian_verified_until.isoformat()}

@app.get("/api/films")
def films(q: str = Query("", max_length=200), genre: str = Query("", max_length=80), country: str = Query("", max_length=80), year_from: int | None = Query(None, ge=1888, le=2100),
          year_to: int | None = Query(None, ge=1888, le=2100), min_rating: float = Query(0, ge=0, le=10), min_oscars: int | None = Query(None, ge=0),
          sort: str = Query("random", pattern="^(random|rating|year|popular|oscars)$"), offset: int = Query(0, ge=0), limit: int = Query(40, ge=1, le=100), seed: str = Query("cinema-mood", max_length=100),
          user: User | None = Depends(optional_user), db: Session = Depends(get_db)):
    # Anonymous browsing is permitted; child filtering applies after sign-in.
    child = bool(user and is_child(user))
    # Give each signed-in member a stable personal shuffle for paginated results.
    personal_seed = f"{seed}:{user.id}" if user else seed
    return search_films(db, q, genre, country, year_from, year_to, min_rating,
                        min_oscars, sort, offset, limit, child, personal_seed, member=bool(user))

@app.get("/film/{film_id:int}", response_class=HTMLResponse)
def film_page(film_id: int, request: Request, user: User | None = Depends(optional_user), db: Session = Depends(get_db)):
    film = db.get(Film, film_id)
    if not film or not film_access_ok(film, user) or (user and is_child(user) and not child_age_ok(film)):
        raise HTTPException(404, "Фильм не найден")
    return templates.TemplateResponse("film.html", {"request": request, "film_id": film_id})

@app.get("/api/films/{film_id:int}")
def film_detail(film_id: int, db: Session = Depends(get_db), user: User | None = Depends(optional_user)):
    f = db.get(Film, film_id)
    if not f: raise HTTPException(404, "Фильм не найден")
    if not film_access_ok(f, user) or (user and is_child(user) and not child_age_ok(f)): raise HTTPException(404, "Фильм не найден")
    reviews = db.scalars(select(Review).where(Review.film_id == film_id, Review.status == "approved").order_by(Review.created_at.desc())).all()
    data = film_dict(f)
    data["reviews"] = [{"id": r.id, "score": r.score, "body": r.body, "created_at": r.created_at.isoformat()} for r in reviews]
    data["user_rating"] = round(sum(r.score for r in reviews)/len(reviews), 1) if reviews else None
    data["review_count"] = len(reviews)
    return data

@app.post("/api/films/{film_id:int}/favorite")
def toggle_favorite(film_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    f = db.get(Film, film_id)
    if not f or not film_access_ok(f, user) or (is_child(user) and not child_age_ok(f)): raise HTTPException(404, "Фильм не найден")
    item = db.scalar(select(Favorite).where(Favorite.user_id == user.id, Favorite.film_id == film_id))
    if item: db.delete(item); result = False
    else: db.add(Favorite(user_id=user.id, film_id=film_id)); result = True
    db.commit()
    return {"favorite": result}

@app.get("/api/me/favorites")
def my_favorites(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.scalars(select(Favorite).where(Favorite.user_id == user.id).order_by(Favorite.created_at.desc())).all()
    return [film_dict(db.get(Film, r.film_id)) for r in rows
            if db.get(Film, r.film_id) and (not is_child(user) or child_age_ok(db.get(Film, r.film_id)))]

@app.post("/api/films/{film_id:int}/watched")
def watched(film_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    f = db.get(Film, film_id)
    if not f or not film_access_ok(f, user) or (is_child(user) and not child_age_ok(f)): raise HTTPException(404, "Фильм не найден")
    db.add(WatchHistory(user_id=user.id, film_id=film_id)); db.commit()
    return {"ok": True}

@app.get("/api/me/history")
def history(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.scalars(select(WatchHistory).where(WatchHistory.user_id == user.id).order_by(WatchHistory.watched_at.desc())).all()
    return [{"entry_id": r.id, "film": film_dict(db.get(Film, r.film_id)), "watched_at": r.watched_at.isoformat()}
            for r in rows if db.get(Film, r.film_id) and (not is_child(user) or child_age_ok(db.get(Film, r.film_id)))]

@app.delete("/api/me/history/{entry_id}")
def delete_history(entry_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    row = db.scalar(select(WatchHistory).where(WatchHistory.id == entry_id, WatchHistory.user_id == user.id))
    if row: db.delete(row); db.commit()
    return {"ok": True}

@app.post("/api/films/{film_id:int}/reviews")
def create_review(film_id: int, data: ReviewIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    f = db.get(Film, film_id)
    if not f or not film_access_ok(f, user) or (is_child(user) and not child_age_ok(f)): raise HTTPException(404, "Фильм не найден")
    row = db.scalar(select(Review).where(Review.user_id == user.id, Review.film_id == film_id))
    if row:
        row.score, row.body, row.status, row.updated_at = data.score, data.body, "pending", datetime.utcnow()
    else:
        db.add(Review(user_id=user.id, film_id=film_id, score=data.score, body=data.body))
    db.commit()
    return {"ok": True, "status": "pending"}

@app.delete("/api/reviews/{review_id}")
def delete_review(review_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    row = db.get(Review, review_id)
    if not row or (row.user_id != user.id and not user.is_admin): raise HTTPException(404, "Отзыв не найден")
    db.delete(row); db.commit()
    return {"ok": True}

@app.post("/api/reviews/{review_id}/report")
def report_review(review_id: int, reason: str = Query(min_length=3, max_length=300), user: User = Depends(current_user), db: Session = Depends(get_db)):
    row = db.get(Review, review_id)
    if not row: raise HTTPException(404, "Отзыв не найден")
    existing = db.scalar(select(Report).where(Report.review_id == review_id, Report.user_id == user.id))
    if existing: raise HTTPException(409, "Вы уже пожаловались на этот отзыв")
    db.add(Report(review_id=review_id, user_id=user.id, reason=reason[:300])); db.commit()
    return {"ok": True}

@app.post("/api/suggestions")
def suggest(data: SuggestIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    # Exact TMDB verification is performed by the admin/import workflow before approval.
    row = FilmSuggestion(user_id=user.id, **data.model_dump())
    db.add(row); db.commit()
    return {"ok": True, "status": "pending", "id": row.id}

@app.get("/api/discover")
def discover(db: Session = Depends(get_db), user: User | None = Depends(optional_user)):
    child = bool(user and is_child(user))
    result = search_films(db, sort="popular", limit=100, child=child, member=bool(user))
    return result

@app.get("/api/catalog/sections")
def film_sections(db: Session = Depends(get_db), user: User | None = Depends(optional_user)):
    child = bool(user and is_child(user))
    base = visible_films(db, child, member=bool(user))
    if child:
        base = base.where(Film.age_rating.in_({"G", "TV-Y", "TV-Y7", "PG"}))
    def pack(stmt): return [film_dict(f) for f in db.scalars(stmt.limit(12)).all()]
    return {
        "popular": pack(base.order_by(Film.popularity.desc())),
        "top_rated": pack(base.order_by(Film.rating.desc(), Film.popularity.desc())),
        "recent": pack(base.order_by(Film.created_at.desc())),
        "oscars": pack(base.where(Film.oscar_wins > 0).order_by(Film.oscar_wins.desc(), Film.rating.desc()))
    }

@app.get("/api/films/{film_id:int}/links")
def film_external_links(film_id: int, user: User | None = Depends(optional_user), db: Session = Depends(get_db)):
    """Discovery links across the public web; viewing links are restricted to legal providers."""
    film = db.get(Film, film_id)
    if not film or not film_access_ok(film, user) or (user and is_child(user) and not child_age_ok(film)):
        raise HTTPException(404, "Фильм не найден")
    title = film.title_original or film.title_ru
    query = quote_plus(f'"{title}" {film.release_year or ""}')
    trailer_query = quote_plus(f'"{title}" {film.release_year or ""} официальный трейлер')
    region = (settings.watch_region or "CA").upper()
    return {
        "search": [
            {"name": "Яндекс", "url": f"https://yandex.com/search/?text={query}"},
            {"name": "Google", "url": f"https://www.google.com/search?q={query}"},
            {"name": "Bing", "url": f"https://www.bing.com/search?q={query}"},
        ],
        "trailers": [
            {"name": "VK Видео — поиск трейлера", "url": f"https://vk.com/video?q={trailer_query}"},
            {"name": "YouTube — поиск трейлера", "url": f"https://www.youtube.com/results?search_query={trailer_query}"},
        ],
        "watch": [
            {"name": "JustWatch — легальные способы просмотра", "url": f"https://www.justwatch.com/{'ca' if region == 'CA' else region.lower()}/search?q={query}", "region": region, "legal_only": True},
            {"name": "VK Видео — поиск публикаций правообладателей", "url": f"https://vk.com/video?q={query}", "legal_only": True, "notice": "Открывайте только публикации официальных каналов правообладателей или лицензированных партнёров."},
        ],
        "note": "Поисковые ссылки ведут на внешние сайты. Наличие фильма и права на его просмотр проверяйте на стороне площадки."
    }

@app.get("/api/films/{film_id:int}/vk-videos")
def film_vk_videos(film_id: int, user: User | None = Depends(optional_user), db: Session = Depends(get_db)):
    """Search public VK Video entries for a film; never downloads or proxies video."""
    film = db.get(Film, film_id)
    if not film or not film_access_ok(film, user) or (user and is_child(user) and not child_age_ok(film)):
        raise HTTPException(404, "Фильм не найден")
    title = film.title_original or film.title_ru
    search_text = f"{title} {film.release_year or ''}".strip()
    search_url = "https://vk.com/video?" + urlencode({"q": search_text})
    if not settings.vk_access_token:
        return {"configured": False, "provider": "VK Видео", "search_url": search_url,
                "items": [], "note": "Для автоматической выдачи VK Видео добавьте VK_ACCESS_TOKEN. Поисковая ссылка уже доступна; выбирайте публикации официальных правообладателей."}
    import httpx
    try:
        response = httpx.get("https://api.vk.com/method/video.search", params={
            "q": search_text, "count": 10, "sort": 2, "adult": 0,
            "access_token": settings.vk_access_token, "v": settings.vk_api_version
        }, timeout=12)
        response.raise_for_status()
        payload = response.json()
        if payload.get("error"):
            # VK can reject a token that lacks the video permission; keep the safe manual search available.
            return {"configured": True, "provider": "VK Видео", "search_url": search_url,
                    "items": [], "note": "VK не разрешил автоматический поиск для этого токена. Откройте поиск VK Видео и выбирайте официальные публикации."}
        raw_items = (payload.get("response") or {}).get("items", [])
        items = []
        for item in raw_items:
            owner_id, video_id = item.get("owner_id"), item.get("id")
            if not owner_id or not video_id:
                continue
            items.append({
                "title": str(item.get("title") or "Видео VK")[:240],
                "url": f"https://vk.com/video{owner_id}_{video_id}",
                "duration": max(0, int(item.get("duration") or 0)),
                "views": max(0, int(item.get("views") or 0)),
                "date": max(0, int(item.get("date") or 0)),
                "thumbnail": next((z.get("url") for z in (item.get("image") or []) if z.get("url", "").startswith("https://")), None)
            })
        return {"configured": True, "provider": "VK Видео", "search_url": search_url,
                "items": items, "note": "Проверяйте, что видео опубликовано правообладателем или лицензированным партнёром."}
    except httpx.HTTPError:
        return {"configured": True, "provider": "VK Видео", "search_url": search_url,
                "items": [], "note": "VK Видео временно недоступно. Попробуйте открыть поиск VK Видео."}

@app.get("/api/film-discovery/search")
def discover_films(q: str = Query(min_length=2, max_length=160), user: User | None = Depends(optional_user), db: Session = Depends(get_db)):
    """Key-free film discovery using public MediaWiki search endpoints.

    Search results are transient: they are never inserted into the curated catalogue.
    """
    if user and is_child(user):
        return {
            "query": q, "items": [], "count": 0, "registered": True,
            "provider": "Wikipedia (public MediaWiki API)",
            "note": "В детском режиме внешний поиск скрыт: возрастные ограничения найденных фильмов не подтверждены. Можно искать среди проверенных фильмов каталога."
        }
    import httpx
    from concurrent.futures import ThreadPoolExecutor

    endpoints = [
        ("ru", "https://ru.wikipedia.org/w/api.php"),
        ("en", "https://en.wikipedia.org/w/api.php"),
    ]
    headers = {"User-Agent": "CinemaMood/1.0 (film discovery; contact: site administrator)"}

    def search_wiki(language: str, endpoint: str):
        # Search the literal query plus a filmography-oriented variant. This helps
        # actor/director queries surface their films without mixing in recommendations.
        variants = ([q, f'{q} фильм', f'{q} фильмы', f'{q} фильмография'] if language == "ru"
                        else [q, f'{q} film', f'{q} films', f'{q} filmography'])
        with httpx.Client(timeout=8, headers=headers, follow_redirects=True) as client:
            titles = []
            for search_term in variants:
                params = {
                    "action": "query", "format": "json", "formatversion": 2,
                    "list": "search", "srsearch": search_term, "srnamespace": 0,
                    "srlimit": 10, "srprop": "snippet",
                }
                response = client.get(endpoint, params=params)
                response.raise_for_status()
                hits = response.json().get("query", {}).get("search", [])
                for hit in hits:
                    title = hit.get("title")
                    if title and title not in titles:
                        titles.append(title)
            titles = titles[:18]
            if not titles:
                return []
            detail_params = {
                "action": "query", "format": "json", "formatversion": 2,
                "prop": "extracts|pageimages|info", "exintro": 1,
                "explaintext": 1, "piprop": "thumbnail", "pithumbsize": 500,
                "inprop": "url", "titles": "|".join(titles[:18]),
            }
            detail = client.get(endpoint, params=detail_params)
            detail.raise_for_status()
            pages = detail.json().get("query", {}).get("pages", [])
            found = []
            for page in pages:
                title = page.get("title") or ""
                extract = (page.get("extract") or "").strip()
                # Filter out obviously unrelated pages; search result must describe a film.
                marker = (title + " " + extract[:1200]).casefold()
                # Require a clear film-related description; broad substring matches
                # such as a person merely mentioning a film are not sufficient.
                import re
                film_pattern = r"(?<![\w])(film|movie|motion picture|feature film|short film|кинофильм|фильм|мультфильм)(?![\w])"
                if not re.search(film_pattern, marker):
                    continue
                year = ""
                match = re.search(r"(?:18|19|20)\d{2}", extract[:1200]) or re.search(r"(?:18|19|20)\d{2}", title)
                if match:
                    year = match.group(0)
                found.append({
                    "title": title,
                    "original_title": title,
                    "year": year,
                    "overview": extract[:650] or "Описание пока отсутствует.",
                    "rating": 0,
                    "poster": (page.get("thumbnail") or {}).get("source"),
                    "source": "Wikipedia",
                    "source_url": page.get("fullurl") or f"https://{language}.wikipedia.org/wiki/" + quote_plus(title.replace(" ", "_")),
                    "language": language,
                })
            return found


    raw = []
    search_errors = 0
    # Keep each public request small; Wikimedia may throttle unusually frequent traffic.
    jobs = [(search_wiki, lang, url) for lang, url in endpoints]
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(fn, lang, url) for fn, lang, url in jobs]
        for future in futures:
            try:
                raw.extend(future.result(timeout=18))
            except Exception:
                search_errors += 1
                continue

    results = []
    seen = set()
    for row in raw:
        key = " ".join((row.get("title") or "").casefold().split())
        if not key or key in seen:
            continue
        seen.add(key)
        # The existing curated catalogue remains authoritative for its 85 films.
        local = db.scalar(select(Film).where(
            or_(func.lower(Film.title_ru) == key, func.lower(Film.title_original) == key)
        ))
        is_open_local = bool(local and film_access_ok(local, user))
        is_locked = bool(local and not film_access_ok(local, user)) or (not bool(user) and not bool(local))
        results.append({
            **row,
            "in_catalog": is_open_local,
            "catalog_id": local.id if is_open_local else None,
            "locked": is_locked,
        })
        if len(results) >= 18:
            break

    return {
        "query": q, "items": results, "count": len(results), "registered": bool(user),
        "search_status": "unavailable" if search_errors == len(jobs) else ("partial" if search_errors else "ok"),
        "provider": "Wikipedia (public MediaWiki API)",
        "note": ("Открытые источники поиска сейчас недоступны. Попробуй ещё раз позже; локальный каталог продолжает работать." if search_errors == len(jobs) else
                 "Часть открытых источников не ответила; показаны найденные результаты." if search_errors else
                 "Поиск без API-ключа по Википедии на русском и английском языках. Это широкий открытый поиск, но не исчерпывающий реестр каждого фильма в мире. Найденные результаты не сохраняются в каталог автоматически; описания, годы и изображения могут отсутствовать или требовать проверки.")
    }

@app.get("/api/internet/search")
def internet_search(q: str = Query(min_length=2, max_length=300), page: int = Query(0, ge=0, le=20), user: User | None = Depends(optional_user)):
    """Whole-web search via Yandex Search API; requires owner-provided credentials."""
    if not settings.yandex_search_api_key or not settings.yandex_folder_id:
        raise HTTPException(503, "Поиск по всему интернету требует YANDEX_SEARCH_API_KEY и YANDEX_FOLDER_ID")
    import httpx, xml.etree.ElementTree as ET
    payload = {
        "query": {"searchType": settings.yandex_search_type, "queryText": q,
                  "familyMode": "FAMILY_MODE_STRICT" if (user and is_child(user)) else "FAMILY_MODE_MODERATE",
                  "page": str(page), "fixTypoMode": "FIX_TYPO_MODE_ON"},
        "folderId": settings.yandex_folder_id,
        "responseFormat": "FORMAT_XML",
        "l10n": "LOCALIZATION_RU" if settings.yandex_search_type == "SEARCH_TYPE_RU" else "LOCALIZATION_EN",
        "maxPassages": "2",
        "groupSpec": {"groupMode": "GROUP_MODE_FLAT", "groupsOnPage": "10", "docsInGroup": "1"}
    }
    try:
        response = httpx.post("https://searchapi.api.cloud.yandex.net/v2/web/search", json=payload,
            headers={"Authorization": f"Api-Key {settings.yandex_search_api_key}", "Content-Type": "application/json"}, timeout=18)
        response.raise_for_status()
        raw = response.json().get("rawData", "")
        root = ET.fromstring(raw)
        def local(tag): return tag.rsplit("}", 1)[-1].lower()
        docs = [node for node in root.iter() if local(node.tag) == "doc"]
        results = []
        for doc in docs[:10]:
            fields = {}
            for node in doc.iter():
                key = local(node.tag)
                value = " ".join(t.strip() for t in node.itertext() if t.strip())
                if key in {"url", "title", "headline", "passage"} and value and key not in fields:
                    fields[key] = value
            url = fields.get("url", "")
            if url.startswith("http"):
                results.append({"title": fields.get("title") or fields.get("headline") or url,
                                "url": url, "snippet": fields.get("passage", "")[:700]})
        return {"query": q, "page": page, "provider": "Yandex Search", "results": results}
    except httpx.HTTPStatusError as exc:
        raise HTTPException(502, f"Ошибка Yandex Search API: HTTP {exc.response.status_code}")
    except (httpx.HTTPError, ET.ParseError, ValueError) as exc:
        raise HTTPException(502, "Не удалось получить или разобрать результаты Яндекс Поиска")

@app.get("/api/films/{film_id:int}/trailer")
def film_trailer(film_id: int, user: User | None = Depends(optional_user), db: Session = Depends(get_db)):
    film=db.get(Film,film_id)
    if not film or not film_access_ok(film, user) or (user and is_child(user) and not child_age_ok(film)): raise HTTPException(404,"Фильм не найден")
    if not settings.tmdb_api_key: raise HTTPException(503,"Трейлеры доступны после настройки TMDB_API_KEY")
    import httpx
    r=httpx.get(f"https://api.themoviedb.org/3/movie/{film.tmdb_id}/videos",headers={"Authorization":f"Bearer {settings.tmdb_api_key}"},params={"language":"ru-RU"},timeout=12)
    r.raise_for_status(); videos=r.json().get("results",[])
    video=next((v for v in videos if v.get("site")=="YouTube" and v.get("type")=="Trailer" and v.get("official")),None)
    if not video: video=next((v for v in videos if v.get("site")=="YouTube" and v.get("type")=="Trailer"),None)
    if not video: raise HTTPException(404,"Трейлер не найден")
    return {"url":"https://www.youtube.com/watch?v="+video["key"],"name":video.get("name", "Трейлер")}

@app.get("/api/surprise")
def surprise(exclude: str = "", user: User | None = Depends(optional_user), db: Session = Depends(get_db)):
    excluded = {int(x) for x in exclude.split(",") if x.isdigit()}
    if user:
        recent_ids = db.scalars(select(SurpriseHistory.film_id).where(SurpriseHistory.user_id == user.id).order_by(SurpriseHistory.created_at.desc()).limit(12)).all()
        excluded.update(recent_ids)
    child = bool(user and is_child(user))
    q = visible_films(db, child, member=bool(user))
    if child:
        q = q.where(Film.age_rating.in_({"G", "TV-Y", "TV-Y7", "PG"}))
    candidates = db.scalars(q.where(Film.id.not_in(excluded))).all()
    if not candidates:
        candidates = db.scalars(q).all()
    if not candidates: raise HTTPException(404, "Каталог пока пуст")
    selected = choice(candidates)
    if user:
        db.add(SurpriseHistory(user_id=user.id, film_id=selected.id)); db.commit()
    return film_dict(selected)

def monday(d: date):
    return d - timedelta(days=d.weekday())

@app.get("/api/weekly")
def weekly(user: User | None = Depends(optional_user), db: Session = Depends(get_db)):
    child = bool(user and is_child(user))
    start = monday(date.today())
    pick = db.scalar(select(WeeklyPick).where(WeeklyPick.week_start == start, WeeklyPick.child_safe == child))
    if not pick:
        q = visible_films(db, child, member=bool(user))
        if child: q = q.where(Film.age_rating.in_({"G", "TV-Y", "TV-Y7", "PG"}))
        recent = db.scalars(select(WeeklyPick.film_id).where(WeeklyPick.child_safe == child).order_by(WeeklyPick.week_start.desc()).limit(8)).all()
        options = db.scalars(q.where(Film.id.not_in(recent))).all()
        if not options:
            options = db.scalars(q).all()
        if not options: raise HTTPException(404, "Нет подходящих фильмов для фильма недели")
        chosen = choice(options)
        pick = WeeklyPick(week_start=start, film_id=chosen.id, child_safe=child)
        db.add(pick); db.commit()
    return film_dict(db.get(Film, pick.film_id))

@app.post("/api/ai/recommend")
def ai_recommend(prompt: str = Query(min_length=2, max_length=1500), user: User = Depends(current_user), db: Session = Depends(get_db)):
    # Retrieval is over the full DB first; the model only ranks retrieved, eligible records.
    child = is_child(user)
    eligible = db.scalars(visible_films(db, child, member=True)).all()
    if child: eligible = [f for f in eligible if child_age_ok(f)]
    if not eligible: return {"items": [], "message": "Каталог пока не импортирован."}
    if not settings.openai_api_key:
        terms = [w.lower() for w in prompt.split() if len(w) > 2]
        ranked = sorted(eligible, key=lambda f: (
            sum(1 for t in terms if t in (f.title_ru+" "+f.title_original+" "+f.overview+" "+" ".join(f.genres)+" "+" ".join(f.countries or [])+" "+f.director+" "+" ".join(f.cast)+" "+f.age_rating).lower()),
            f.rating, f.popularity), reverse=True)
        return {"mode": "local-search", "items": [{"film": film_dict(f), "reason": "Совпадение по описанию, жанрам или участникам; отсортировано по рейтингу."} for f in ranked[:12]]}
    from openai import OpenAI
    client = OpenAI(api_key=settings.openai_api_key)
    # Candidate set is all eligible films; chunk to keep prompts bounded, then rank candidate IDs.
    # For large deployments, replace this with pgvector embeddings and hybrid retrieval.
    candidates = [{"id": f.id, "title": f.title_ru, "original": f.title_original,
                   "genres": f.genres, "countries": f.countries, "year": f.release_year, "rating": f.rating,
                   "runtime": f.runtime, "director": f.director, "cast": f.cast[:8],
                   "age_rating": f.age_rating, "oscar_wins": f.oscar_wins,
                   "overview": f.overview[:500]} for f in eligible]
    chunks = [candidates[i:i+150] for i in range(0, len(candidates), 150)]
    import json
    shortlist = []
    reasons = {}
    for chunk in chunks:
        result = client.chat.completions.create(
            model=settings.openai_model, temperature=0,
            response_format={"type": "json_object"},
            messages=[{"role":"system","content":"Ты кинокритик-рекомендатель. Выбирай только ID из переданного каталога. Не добавляй фактов. Ответ JSON: {\"ids\":[...],\"reasons\":{\"id\":\"краткое объяснение\"}}. Учитывай запрос, настроение, жанры, актёров, год, рейтинг. Детский профиль: выбирай только безопасные фильмы."},
                      {"role":"user","content":f"Запрос: {prompt[:1500]}\nДетский режим: {child}\nКаталог: {chunk}"}])
        payload = json.loads(result.choices[0].message.content)
        valid_ids = {item["id"] for item in chunk}
        for fid in payload.get("ids", []):
            if isinstance(fid, int) and fid in valid_ids and fid not in shortlist:
                shortlist.append(fid)
        reasons.update({str(k): str(v)[:300] for k,v in payload.get("reasons", {}).items()})
    id_map = {f.id:f for f in eligible}
    shortlisted = [id_map[i] for i in shortlist if i in id_map]
    if shortlisted:
        final = client.chat.completions.create(
            model=settings.openai_model, temperature=0,
            response_format={"type":"json_object"},
            messages=[{"role":"system","content":"Ранжируй кандидатов по соответствию запросу. Выбирай только переданные ID, не выдумывай факты. JSON: {\"ids\":[...]}"},
                      {"role":"user","content":f"Запрос: {prompt[:1500]}\nКандидаты: {[{'id':f.id,'title':f.title_ru,'original':f.title_original,'genres':f.genres,'countries':f.countries,'year':f.release_year,'rating':f.rating,'runtime':f.runtime,'director':f.director,'cast':f.cast[:8],'age_rating':f.age_rating,'oscar_wins':f.oscar_wins,'overview':f.overview[:350]} for f in shortlisted]}"}])
        final_ids = json.loads(final.choices[0].message.content).get("ids", [])
        ordered = [id_map[i] for i in final_ids if isinstance(i,int) and i in id_map]
    else:
        ordered = []
    return {"mode":"ai","items":[{"film":film_dict(f),"reason":reasons.get(str(f.id),"Подобран ИИ по вашему запросу.")} for f in ordered[:12]]}

@app.post("/api/admin/users/{user_id}/promote")
def promote_admin(user_id: int, admin: User = Depends(admin_user), db: Session = Depends(get_db)):
    target = db.get(User,user_id)
    if not target: raise HTTPException(404,"Пользователь не найден")
    target.is_admin = True; db.commit()
    return {"ok":True}


@app.get("/api/admin/overview")
def admin_overview(admin: User = Depends(admin_user), db: Session = Depends(get_db)):
    return {"users": db.scalar(select(func.count(User.id))) or 0,
            "films": db.scalar(select(func.count(Film.id))) or 0,
            "pending_reviews": db.scalar(select(func.count(Review.id)).where(Review.status=="pending")) or 0,
            "pending_suggestions": db.scalar(select(func.count(FilmSuggestion.id)).where(FilmSuggestion.status=="pending")) or 0,
            "reports": db.scalar(select(func.count(Report.id))) or 0}

@app.get("/api/admin/reviews")
def admin_reviews(admin: User = Depends(admin_user), db: Session = Depends(get_db)):
    rows = db.scalars(select(Review).where(Review.status=="pending").order_by(Review.created_at)).all()
    return [{"id":r.id,"film_id":r.film_id,"user_id":r.user_id,"score":r.score,"body":r.body} for r in rows]

@app.post("/api/admin/reviews/{review_id}/approve")
def approve_review(review_id: int, admin: User = Depends(admin_user), db: Session = Depends(get_db)):
    r=db.get(Review,review_id)
    if not r: raise HTTPException(404,"Отзыв не найден")
    r.status="approved"; db.commit()
    return {"ok":True}

@app.delete("/api/admin/reviews/{review_id}")
def reject_review(review_id: int, admin: User = Depends(admin_user), db: Session = Depends(get_db)):
    r=db.get(Review,review_id)
    if r: db.delete(r); db.commit()
    return {"ok":True}

@app.get("/api/admin/reports")
def admin_reports(admin: User = Depends(admin_user), db: Session = Depends(get_db)):
    rows = db.scalars(select(Report).order_by(Report.created_at.desc()).limit(200)).all()
    return [{"id": r.id, "review_id": r.review_id, "user_id": r.user_id, "reason": r.reason,
             "created_at": r.created_at.isoformat()} for r in rows]

@app.delete("/api/admin/reports/{report_id}")
def dismiss_report(report_id: int, admin: User = Depends(admin_user), db: Session = Depends(get_db)):
    report = db.get(Report, report_id)
    if report:
        db.delete(report); db.commit()
    return {"ok": True}

@app.get("/api/admin/users")
def admin_users(offset: int = 0, limit: int = 50, admin: User = Depends(admin_user), db: Session = Depends(get_db)):
    limit = max(1, min(limit, 100)); offset = max(0, offset)
    rows = db.scalars(select(User).order_by(User.created_at.desc()).offset(offset).limit(limit)).all()
    return [{"id": u.id, "username": u.username, "email": u.email, "age": age_years(u.birth_date),
             "is_admin": u.is_admin, "created_at": u.created_at.isoformat()} for u in rows]

@app.post("/api/admin/suggestions/{suggestion_id}/approve")
def approve_suggestion(suggestion_id: int, admin: User = Depends(admin_user), db: Session = Depends(get_db)):
    row = db.get(FilmSuggestion, suggestion_id)
    if not row: raise HTTPException(404, "Предложение не найдено")
    if not settings.tmdb_api_key: raise HTTPException(503, "TMDB_API_KEY не настроен: проверка существования фильма невозможна")
    import httpx
    try:
        response = httpx.get("https://api.themoviedb.org/3/search/movie", params={"query": row.title, "year": row.release_year},
                             headers={"Authorization": f"Bearer {settings.tmdb_api_key}"}, timeout=12)
        response.raise_for_status(); results = response.json().get("results", [])
    except Exception:
        raise HTTPException(502, "Не удалось проверить фильм через TMDB")
    if not results: raise HTTPException(422, "Фильм не найден в TMDB; предложение оставлено на модерации")
    match = results[0]
    existing = db.scalar(select(Film).where(Film.tmdb_id == match["id"]))
    if existing:
        row.status = "duplicate"; db.commit()
        return {"ok": True, "status": "duplicate", "film_id": existing.id}
    row.status = "approved_pending_import"
    db.commit()
    return {"ok": True, "status": row.status, "tmdb_id": match["id"], "message": "Проверено в TMDB; требуется запуск курируемого импорта полной карточки."}

@app.patch("/api/admin/films/{film_id}")
def admin_update_film(film_id: int, data: FilmAdminUpdateIn, admin: User = Depends(admin_user), db: Session = Depends(get_db)):
    film = db.get(Film, film_id)
    if not film: raise HTTPException(404, "Фильм не найден")
    values = data.model_dump(exclude_unset=True)
    if "category" in values and values["category"] not in {"hollywood", "world", "soviet"}:
        raise HTTPException(422, "Неизвестная категория каталога")
    if "oscar_years" in values and values["oscar_years"] is not None and any(y < 1929 or y > date.today().year for y in values["oscar_years"]):
        raise HTTPException(422, "Некорректный год премии")
    if values.get("oscar_nominations", film.oscar_nominations) < values.get("oscar_wins", film.oscar_wins):
        raise HTTPException(422, "Номинаций не может быть меньше побед")
    for key, value in values.items():
        if value is None and key not in {"poster_path", "runtime"}:
            raise HTTPException(422, f"Поле {key} не может быть пустым")
        setattr(film, key, value)
    db.commit()
    return {"ok": True, "film": film_dict(film)}

@app.get("/api/admin/films")
def admin_films(q: str = "", offset: int = 0, limit: int = 50, admin: User = Depends(admin_user), db: Session = Depends(get_db)):
    stmt = select(Film)
    if q:
        like = f"%{q.strip()}%"
        stmt = stmt.where(or_(Film.title_ru.ilike(like), Film.title_original.ilike(like)))
    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    rows = db.scalars(stmt.order_by(Film.title_ru).offset(max(0, offset)).limit(max(1, min(limit, 100)))).all()
    return {"total": total, "items": [film_dict(f) for f in rows]}

@app.delete("/api/admin/films/{film_id}")
def admin_delete_film(film_id: int, admin: User = Depends(admin_user), db: Session = Depends(get_db)):
    film = db.get(Film, film_id)
    if not film: raise HTTPException(404, "Фильм не найден")
    review_ids = db.scalars(select(Review.id).where(Review.film_id == film_id)).all()
    if review_ids: db.execute(delete(Report).where(Report.review_id.in_(review_ids)))
    db.execute(delete(Review).where(Review.film_id == film_id))
    db.execute(delete(Favorite).where(Favorite.film_id == film_id))
    db.execute(delete(WatchHistory).where(WatchHistory.film_id == film_id))
    db.execute(delete(WeeklyPick).where(WeeklyPick.film_id == film_id))
    db.delete(film); db.commit()
    return {"ok": True}

@app.post("/api/admin/weekly/{film_id}")
def admin_set_weekly(film_id: int, child_safe: bool = False, admin: User = Depends(admin_user), db: Session = Depends(get_db)):
    film = db.get(Film, film_id)
    if not film or film.rating < 7 or (child_safe and not child_age_ok(film)):
        raise HTTPException(422, "Фильм не подходит для выбранной версии фильма недели")
    start = monday(date.today())
    pick = db.scalar(select(WeeklyPick).where(WeeklyPick.week_start == start, WeeklyPick.child_safe == child_safe))
    if pick: pick.film_id = film_id
    else: db.add(WeeklyPick(week_start=start, film_id=film_id, child_safe=child_safe))
    db.commit()
    return {"ok": True, "film_id": film_id, "week_start": start.isoformat()}

@app.get("/api/admin/suggestions")
def admin_suggestions(admin: User = Depends(admin_user), db: Session = Depends(get_db)):
    rows=db.scalars(select(FilmSuggestion).where(FilmSuggestion.status=="pending")).all()
    return [{"id":r.id,"title":r.title,"year":r.release_year,"country":r.country,"genre":r.genre,"description":r.description} for r in rows]

@app.post("/api/admin/suggestions/{suggestion_id}/reject")
def reject_suggestion(suggestion_id: int, admin: User = Depends(admin_user), db: Session = Depends(get_db)):
    r=db.get(FilmSuggestion,suggestion_id)
    if not r: raise HTTPException(404,"Предложение не найдено")
    r.status="rejected"; db.commit()
    return {"ok":True}
