from datetime import datetime, timedelta, date, timezone
import jwt
from jwt.exceptions import InvalidTokenError as JWTError
from argon2 import PasswordHasher
from fastapi import Depends, HTTPException, Request
from sqlalchemy.orm import Session
from app.config import settings
from app.db import get_db
from app.models import User

password_hash = PasswordHasher()
ALGORITHM = "HS256"

def hash_secret(value: str) -> str:
    return password_hash.hash(value)

def verify_secret(value: str, hashed: str) -> bool:
    try:
        return password_hash.verify(hashed, value)
    except Exception:
        return False

def issue_token(user: User) -> str:
    payload = {"sub": str(user.id), "exp": datetime.now(timezone.utc) + timedelta(days=7)}
    return jwt.encode(payload, settings.secret_key, algorithm=ALGORITHM)

def optional_user(request: Request, db: Session = Depends(get_db)) -> User | None:
    token = request.cookies.get("cm_session")
    if not token:
        return None
    try:
        uid = int(jwt.decode(token, settings.secret_key, algorithms=[ALGORITHM])["sub"])
    except (JWTError, ValueError, KeyError):
        return None
    return db.get(User, uid)

def current_user(request: Request, db: Session = Depends(get_db)) -> User:
    token = request.cookies.get("cm_session")
    if not token:
        raise HTTPException(401, "Требуется вход")
    try:
        uid = int(jwt.decode(token, settings.secret_key, algorithms=[ALGORITHM])["sub"])
    except (JWTError, ValueError, KeyError):
        raise HTTPException(401, "Сессия недействительна")
    user = db.get(User, uid)
    if not user:
        raise HTTPException(401, "Пользователь не найден")
    return user

def admin_user(user: User = Depends(current_user)) -> User:
    if not user.is_admin:
        raise HTTPException(403, "Недостаточно прав")
    return user

def age_years(birth: date) -> int:
    today = date.today()
    return today.year - birth.year - ((today.month, today.day) < (birth.month, birth.day))

def is_child(user: User) -> bool:
    # Guardian verification grants a short-lived, server-side adult-mode session.
    if user.guardian_verified_until and user.guardian_verified_until > datetime.utcnow():
        return False
    return age_years(user.birth_date) <= 10

def assert_parent_pin(user: User, pin: str):
    if not user.parent_pin_hash or not verify_secret(pin, user.parent_pin_hash):
        raise HTTPException(403, "Неверный родительский PIN-код")
