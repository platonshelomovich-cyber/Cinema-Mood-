from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    database_url: str = "sqlite:///./cinema_mood.db"
    secret_key: str = "dev-only-change-this-secret"
    tmdb_api_key: str = ""
    openai_api_key: str = ""
    openai_model: str = "gpt-4.1-mini"
    yandex_search_api_key: str = ""
    yandex_folder_id: str = ""
    yandex_search_type: str = "SEARCH_TYPE_COM"
    vk_access_token: str = ""
    vk_api_version: str = "5.199"
    watch_region: str = "CA"
    public_base_url: str = "http://localhost:8000"
    parent_setup_token: str = ""
    cookie_secure: bool = False
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
