from datetime import datetime, date
from sqlalchemy import String, Integer, Float, Boolean, Date, DateTime, Text, ForeignKey, UniqueConstraint, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db import Base

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    birth_date: Mapped[date] = mapped_column(Date)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    avatar_url: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    parent_pin_hash: Mapped[str | None] = mapped_column(String(255), nullable=True)
    guardian_verified_until: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    favorites = relationship("Favorite", cascade="all, delete-orphan")
    reviews = relationship("Review", cascade="all, delete-orphan")

class Film(Base):
    __tablename__ = "films"
    id: Mapped[int] = mapped_column(primary_key=True)
    tmdb_id: Mapped[int] = mapped_column(Integer, unique=True, index=True)
    title_ru: Mapped[str] = mapped_column(String(300), index=True)
    title_original: Mapped[str] = mapped_column(String(300), index=True)
    release_year: Mapped[int] = mapped_column(Integer, index=True)
    countries: Mapped[list] = mapped_column(JSON, default=list)
    genres: Mapped[list] = mapped_column(JSON, default=list)
    rating: Mapped[float] = mapped_column(Float, index=True)
    poster_path: Mapped[str | None] = mapped_column(String(500), nullable=True)
    image_kind: Mapped[str] = mapped_column(String(20), default="poster")  # poster or still
    access_level: Mapped[str] = mapped_column(String(20), default="public", index=True)  # public or member
    overview: Mapped[str] = mapped_column(Text, default="")
    runtime: Mapped[int | None] = mapped_column(Integer, nullable=True)
    director: Mapped[str] = mapped_column(String(300), default="")
    cast: Mapped[list] = mapped_column(JSON, default=list)
    age_rating: Mapped[str] = mapped_column(String(20), default="NR")
    oscar_wins: Mapped[int] = mapped_column(Integer, default=0)
    oscar_nominations: Mapped[int] = mapped_column(Integer, default=0)
    oscar_years: Mapped[list] = mapped_column(JSON, default=list)
    category: Mapped[str] = mapped_column(String(20), index=True)  # hollywood/world/soviet
    popularity: Mapped[float] = mapped_column(Float, default=0)
    watch_url: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    trailer_url: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    source_url: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    interesting_fact: Mapped[str] = mapped_column(Text, default="")
    fact_source_url: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    why_watch: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Favorite(Base):
    __tablename__ = "favorites"
    __table_args__ = (UniqueConstraint("user_id", "film_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    film_id: Mapped[int] = mapped_column(ForeignKey("films.id", ondelete="CASCADE"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class WatchHistory(Base):
    __tablename__ = "watch_history"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    film_id: Mapped[int] = mapped_column(ForeignKey("films.id", ondelete="CASCADE"), index=True)
    watched_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Review(Base):
    __tablename__ = "reviews"
    __table_args__ = (UniqueConstraint("user_id", "film_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    film_id: Mapped[int] = mapped_column(ForeignKey("films.id", ondelete="CASCADE"), index=True)
    score: Mapped[int] = mapped_column(Integer)
    body: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="pending", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class FilmSuggestion(Base):
    __tablename__ = "film_suggestions"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    title: Mapped[str] = mapped_column(String(300))
    release_year: Mapped[int | None] = mapped_column(Integer, nullable=True)
    country: Mapped[str] = mapped_column(String(100), default="")
    genre: Mapped[str] = mapped_column(String(100), default="")
    description: Mapped[str] = mapped_column(Text, default="")
    poster_url: Mapped[str] = mapped_column(String(1000), default="")
    status: Mapped[str] = mapped_column(String(20), default="pending", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class WeeklyPick(Base):
    __tablename__ = "weekly_picks"
    id: Mapped[int] = mapped_column(primary_key=True)
    week_start: Mapped[date] = mapped_column(Date, index=True)
    film_id: Mapped[int] = mapped_column(ForeignKey("films.id"))
    child_safe: Mapped[bool] = mapped_column(Boolean, default=False)
    __table_args__ = (UniqueConstraint("week_start", "child_safe"),)

class Report(Base):
    __tablename__ = "reports"
    id: Mapped[int] = mapped_column(primary_key=True)
    review_id: Mapped[int] = mapped_column(ForeignKey("reviews.id", ondelete="CASCADE"))
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    reason: Mapped[str] = mapped_column(String(300))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class SurpriseHistory(Base):
    __tablename__ = "surprise_history"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=True, index=True)
    film_id: Mapped[int] = mapped_column(ForeignKey("films.id", ondelete="CASCADE"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
