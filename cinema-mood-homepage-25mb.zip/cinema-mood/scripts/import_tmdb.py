import os, sys, asyncio, httpx
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from collections import defaultdict
from sqlalchemy import select, func
from app.db import Base, engine, SessionLocal
from app.models import Film

BASE = "https://api.themoviedb.org/3"
KEY = os.getenv("TMDB_API_KEY")
if not KEY:
    raise SystemExit("Set TMDB_API_KEY in .env before import.")
HEADERS = {"Authorization": f"Bearer {KEY}", "accept": "application/json"}
# The quotas are deliberately mutually exclusive:
# Soviet = USSR; Hollywood = US production; World = non-US and non-USSR,
# excluding African countries and South Korea.
AFRICA = {"DZ","AO","BJ","BW","BF","BI","CV","CM","CF","TD","KM","CG","CD","CI","DJ","EG","GQ","ER","SZ","ET","GA","GM","GH","GN","GW","KE","LS","LR","LY","MG","MW","ML","MR","MU","MA","MZ","NA","NE","NG","RW","ST","SN","SC","SL","SO","ZA","SS","SD","TZ","TG","TN","UG","ZM","ZW","EH","RE","YT","SH"}
SOUTH_KOREA = {"KR"}

async def get(client, path, params=None):
    r = await client.get(BASE + path, params=params or {}, headers=HEADERS)
    r.raise_for_status()
    return r.json()

async def details(client, tmdb_id):
    return await get(client, f"/movie/{tmdb_id}", {"append_to_response":"credits,release_dates"})

def rating_cert(detail):
    releases = detail.get("release_dates",{}).get("results",[])
    # Prefer North American certificates for consistency, then use a verified
    # certificate from another release territory when NA data is unavailable.
    ordered = sorted(releases, key=lambda r: 0 if r.get("iso_3166_1") in ("US", "CA") else 1)
    for rel in ordered:
        for item in rel.get("release_dates",[]):
            cert = (item.get("certification") or "").strip()
            if cert: return cert
    return "NR"

def choose_category(codes):
    codes=set(codes or [])
    # Categories are mutually exclusive. Excluded countries are never allowed
    # into the world bucket, including co-productions.
    if "SU" in codes: return "soviet"
    if codes & (AFRICA | SOUTH_KOREA): return None
    if "US" in codes: return "hollywood"
    if codes: return "world"
    return None

async def main():
    Base.metadata.create_all(engine)
    buckets=defaultdict(dict)
    async with httpx.AsyncClient(timeout=30) as client:
        # Discover high-rated movies across multiple pages. We only commit rows
        # whose category can be unambiguously assigned and whose TMDB score >= 7.
        for page in range(1, 501):
            data=await get(client,"/discover/movie",{
                "include_adult":"false","language":"ru-RU","sort_by":"vote_average.desc",
                "vote_count.gte":100,"vote_average.gte":7,"page":page
            })
            if not data.get("results"): break
            for item in data["results"]:
                mid=item["id"]
                if any(mid in b for b in buckets.values()): continue
                try:
                    d=await details(client,mid)
                    codes=[c["iso_3166_1"] for c in d.get("production_countries",[])]
                    cat=choose_category(codes)
                    if cat=="hollywood" and len(buckets[cat])<1300: pass
                    elif cat=="world" and len(buckets[cat])<570: pass
                    else: continue
                    credits=d.get("credits",{})
                    crew=credits.get("crew",[])
                    director=next((x["name"] for x in crew if x.get("job")=="Director"),"")
                    cast=[x["name"] for x in credits.get("cast",[])[:12]]
                    genres=[x["name"] for x in d.get("genres",[])]
                    ru=d.get("title") or item.get("title") or ""
                    original=d.get("original_title") or ""
                    year=int((d.get("release_date") or "0000")[:4])
                    if not year or not ru or not original: continue
                    # Required catalogue fields must come from TMDB; incomplete
                    # records are skipped rather than filled with invented data.
                    if not d.get("poster_path") or not d.get("overview") or not (d.get("runtime") or 0): continue
                    if not director or not cast or not rating_cert(d) or rating_cert(d) == "NR": continue
                    if not (7.0 <= float(d.get("vote_average") or 0) <= 10.0): continue
                    buckets[cat][mid]=dict(tmdb_id=mid,title_ru=ru,title_original=original,
                        release_year=year,countries=codes,genres=genres,
                        rating=float(d.get("vote_average") or 0),poster_path=d.get("poster_path"),
                        overview=d.get("overview") or "",runtime=d.get("runtime"),
                        director=director,cast=cast,age_rating=rating_cert(d),
                        category=cat,popularity=float(d.get("popularity") or 0))
                    print(cat, len(buckets[cat]), ru)
                except Exception as e:
                    print("skip",mid,e,file=sys.stderr)
            if len(buckets["hollywood"])>=1300 and len(buckets["world"])>=570: break

        # Soviet classics are imported separately; only movies with USSR country
        # code, TMDB vote >= 7.0, and non-duplicate TMDB IDs qualify.
        for page in range(1, 30):
            data=await get(client,"/discover/movie",{"language":"ru-RU","sort_by":"vote_average.desc",
                "vote_count.gte":10,"vote_average.gte":7,"with_origin_country":"SU","page":page})
            for item in data.get("results",[]):
                mid=item["id"]
                if any(mid in b for b in buckets.values()) or len(buckets["soviet"])>=30: continue
                try:
                    d=await details(client,mid)
                    codes=[c["iso_3166_1"] for c in d.get("production_countries",[])]
                    if "SU" not in codes: continue
                    credits=d.get("credits",{}); crew=credits.get("crew",[])
                    soviet_director=next((x["name"] for x in crew if x.get("job")=="Director"),"")
                    soviet_cast=[x["name"] for x in credits.get("cast",[])[:12]]
                    soviet_year=int((d.get("release_date") or "0000")[:4])
                    if not (1888 <= soviet_year <= 2100): continue
                    if not d.get("poster_path") or not d.get("overview") or not (d.get("runtime") or 0) or not soviet_director or not soviet_cast or rating_cert(d) in (None, "NR"): continue
                    if not (7.0 <= float(d.get("vote_average") or 0) <= 10.0): continue
                    buckets["soviet"][mid]=dict(tmdb_id=mid,title_ru=d.get("title",""),
                        title_original=d.get("original_title",""),release_year=soviet_year,
                        countries=codes,genres=[x["name"] for x in d.get("genres",[])],
                        rating=float(d.get("vote_average") or 0),poster_path=d.get("poster_path"),
                        overview=d.get("overview") or "",runtime=d.get("runtime"),
                        director=soviet_director,
                        cast=soviet_cast,
                        age_rating=rating_cert(d),category="soviet",popularity=float(d.get("popularity") or 0))
                except Exception as e: print("skip soviet",mid,e,file=sys.stderr)
            if len(buckets["soviet"])>=30: break

    expected={"hollywood":1300,"world":570,"soviet":30}
    actual={k:len(v) for k,v in buckets.items()}
    print("Import candidate counts:",actual)
    if actual != expected:
        raise SystemExit(f"Quota validation failed. Expected {expected}, got {actual}. No partial import performed.")
    rows=[row for group in buckets.values() for row in group.values()]
    if len({r["tmdb_id"] for r in rows})!=1900: raise SystemExit("Duplicate TMDB IDs detected.")
    if any(not (7.0 <= r["rating"] <= 10.0) for r in rows): raise SystemExit("Rating outside 7.0–10.0 detected.")
    if any(not r["title_ru"] or not r["title_original"] or not (1888 <= r["release_year"] <= 2100) for r in rows):
        raise SystemExit("Missing/invalid title or release year detected.")
    if any(r["category"] not in expected for r in rows): raise SystemExit("Unexpected category detected.")
    with SessionLocal() as db:
        existing_ids = set(db.scalars(select(Film.tmdb_id)).all())
        incoming_ids = {r["tmdb_id"] for r in rows}
        if existing_ids and not existing_ids.issubset(incoming_ids):
            raise SystemExit("Database contains unrelated film rows. Reconcile or back up the database before importing the exact 1,900-film collection.")
        for row in rows:
            old=db.scalar(select(Film).where(Film.tmdb_id==row["tmdb_id"]))
            if old:
                for k,v in row.items(): setattr(old,k,v)
            else: db.add(Film(**row))
        db.commit()
        count=db.scalar(select(func.count(Film.id)))
        categories={k:db.scalar(select(func.count(Film.id)).where(Film.category==k)) for k in expected}
        print("Database rows:",count,"category counts:",categories)
        if count != 1900 or categories != expected:
            raise SystemExit("Database must contain exactly 1900 films with the required category quotas. Existing extra rows need review before import.")

if __name__=="__main__": asyncio.run(main())
