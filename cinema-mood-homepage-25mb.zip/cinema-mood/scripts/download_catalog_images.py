"""Download and validate the 85 curated catalogue images.

Run from the project root in an environment with internet access:
    python scripts/download_catalog_images.py
Only actual image files are accepted. Failed items keep their existing source URL.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import re
import sqlite3
from pathlib import Path
from urllib.parse import urlparse
import httpx

ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / "cinema_mood.db"
MANIFEST = ROOT / "data" / "images_manifest.json"
OUT = ROOT / "app" / "static" / "posters"
OUT.mkdir(parents=True, exist_ok=True)
ITEMS = json.loads(MANIFEST.read_text(encoding="utf-8"))
HEADERS = {"User-Agent": "CinemaMood/1.0 (catalog poster downloader)"}
MAX_BYTES = 12 * 1024 * 1024
SIGNATURES = {
    "image/jpeg": lambda b: b.startswith(b"\xff\xd8\xff"),
    "image/png": lambda b: b.startswith(b"\x89PNG\r\n\x1a\n"),
    "image/webp": lambda b: len(b) > 12 and b[:4] == b"RIFF" and b[8:12] == b"WEBP",
    "image/gif": lambda b: b.startswith((b"GIF87a", b"GIF89a")),
}
EXTENSIONS = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp", "image/gif": ".gif"}


def fetch(item):
    try:
        with httpx.Client(timeout=12, follow_redirects=True, headers=HEADERS) as client:
            response = client.get(item["image_url"])
            response.raise_for_status()
        mime = response.headers.get("content-type", "").split(";", 1)[0].lower()
        body = response.content
        if mime not in SIGNATURES or len(body) < 256 or len(body) > MAX_BYTES or not SIGNATURES[mime](body):
            raise ValueError(f"not a valid supported image ({mime}, {len(body)} bytes)")
        safe = re.sub(r"[^a-z0-9]+", "-", item["title_original"].lower()).strip("-")[:70] or "film"
        name = f"{item['film_id']}-{safe}{EXTENSIONS[mime]}"
        temp = OUT / (name + ".part")
        temp.write_bytes(body)
        temp.replace(OUT / name)
        return item, f"/static/posters/{name}", None
    except Exception as exc:
        return item, None, f"{type(exc).__name__}: {exc}"


con = sqlite3.connect(DB)
saved = failed = 0
with ThreadPoolExecutor(max_workers=8) as pool:
    futures = [pool.submit(fetch, item) for item in ITEMS]
    for future in as_completed(futures):
        item, local_path, error = future.result()
        if local_path:
            con.execute("UPDATE films SET poster_path=?, image_kind=? WHERE id=?",
                        (local_path, item.get("image_kind", "poster"), item["film_id"]))
            saved += 1
            print(f"OK {item['title_ru']}")
        else:
            failed += 1
            print(f"SKIP {item['title_ru']}: {error}")
con.commit()
con.close()
print(f"Downloaded: {saved}; failed: {failed}; manifest entries: {len(ITEMS)}")
