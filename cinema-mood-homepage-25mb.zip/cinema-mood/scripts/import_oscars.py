"""Import reviewed Academy Award counts from a verified CSV source.

CSV columns: tmdb_id,wins,nominations,years
`years` is a pipe-separated list, e.g. 1998|1999.
"""
import csv, sys
from pathlib import Path
from sqlalchemy import select
from app.db import Base, engine, SessionLocal
from app.models import Film

path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("data/oscars.csv")
if not path.exists(): raise SystemExit(f"CSV not found: {path}")
Base.metadata.create_all(engine)
updates=[]; seen=set()
with path.open(encoding="utf-8-sig", newline="") as f:
    for row in csv.DictReader(line for line in f if not line.lstrip().startswith("#")):
        mid=int(row["tmdb_id"]); wins=int(row["wins"]); nominations=int(row["nominations"])
        years=[int(x) for x in (row.get("years") or "").split("|") if x.strip()]
        if mid in seen: raise SystemExit(f"Duplicate tmdb_id in awards CSV: {mid}")
        if wins < 0 or nominations < wins or any(y < 1929 or y > 2100 for y in years):
            raise SystemExit(f"Invalid awards values for tmdb_id={mid}")
        seen.add(mid); updates.append((mid,wins,nominations,years))
with SessionLocal() as db:
    missing=[]
    for mid,wins,nominations,years in updates:
        film=db.scalar(select(Film).where(Film.tmdb_id==mid))
        if not film: missing.append(mid); continue
        film.oscar_wins=wins; film.oscar_nominations=nominations; film.oscar_years=years
    if missing: raise SystemExit(f"Unknown TMDB IDs; no commit performed: {missing[:20]}")
    db.commit()
print(f"Updated verified Oscar data for {len(updates)} films.")
