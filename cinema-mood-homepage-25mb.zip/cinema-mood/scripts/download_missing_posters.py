#!/usr/bin/env python3
"""Replace generated placeholders with matching Wikipedia lead posters/images.

No API key required. Existing original Cinema Mood artwork is retained whenever
Wikipedia cannot provide a portrait image for the matching film article.
Run from project root: python scripts/download_missing_posters.py
"""
import re, sqlite3, time
from pathlib import Path
from urllib.parse import quote
import httpx
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"app"/"static"/"posters"; OUT.mkdir(parents=True, exist_ok=True)
DB=ROOT/"cinema_mood.db"
API="https://en.wikipedia.org/w/api.php"
HEADERS={"User-Agent":"CinemaMoodPosterFetcher/1.1 (non-commercial film catalogue)"}
con=sqlite3.connect(DB)
rows=con.execute("SELECT id,title_original,title_ru,release_year,poster_path,image_kind FROM films ORDER BY id").fetchall()
ok=miss=kept=0
with httpx.Client(timeout=25,headers=HEADERS,follow_redirects=True) as c:
 for fid,original,russian,year,current,kind in rows:
  # Never replace a previously verified real poster. Generated artwork can be replaced.
  if current and kind not in ("artwork", "still", None):
   kept+=1; continue
  candidates=[]
  for title in (original,russian):
   if not title: continue
   try:
    sr=c.get(API,params={"action":"query","format":"json","list":"search","srsearch":f'"{title}" {year or ""} film','srlimit':6}); sr.raise_for_status()
    candidates.extend(sr.json().get("query",{}).get("search",[]))
   except Exception: pass
  seen=set(); found=None
  for item in candidates:
   article=item.get("title","")
   if not article or article.casefold() in seen: continue
   seen.add(article.casefold())
   # Require the article title to contain a substantial part of the film title.
   norm=lambda x: re.sub(r'[^a-z0-9а-я]+','', (x or '').casefold())
   key=norm(original); ru=norm(russian); art=norm(article)
   if not ((key and (key in art or art in key and len(art)>5)) or (ru and (ru in art or art in ru and len(art)>5))):
    continue
   try:
    pr=c.get(API,params={"action":"query","format":"json","prop":"pageimages|info","piprop":"thumbnail","pithumbsize":900,"inprop":"url","titles":article}); pr.raise_for_status()
    pages=pr.json().get("query",{}).get("pages",{}); page=next(iter(pages.values()),{}); thumb=page.get("thumbnail",{})
    w,h=thumb.get("width",0),thumb.get("height",0)
    if thumb.get("source") and h>=w*1.12 and h>=260:
     found=(thumb["source"],page.get("fullurl") or "https://en.wikipedia.org/wiki/"+quote(article.replace(' ','_'))); break
   except Exception: continue
  if not found:
   miss+=1; continue
  try:
   url,source=found; resp=c.get(url); resp.raise_for_status()
   ctype=resp.headers.get('content-type','').lower()
   if not ctype.startswith('image/'): raise ValueError('not an image response')
   ext='.jpg' if 'jpeg' in ctype else '.png' if 'png' in ctype else '.webp'
   name=f'{fid}-wiki-poster{ext}'; (OUT/name).write_bytes(resp.content)
   con.execute("UPDATE films SET poster_path=?, image_kind='poster', source_url=COALESCE(source_url,?) WHERE id=?",('/static/posters/'+name,source,fid))
   ok+=1
  except Exception: miss+=1
  if (ok+miss)%25==0: con.commit(); print(f'Processed {ok+miss}/{len(rows)}; replaced={ok}; retained placeholders={miss}')
  time.sleep(.12)
con.commit(); con.close()
print(f'Finished: real images added/replaced={ok}; no matching image={miss}; already verified posters retained={kept}; total={len(rows)}')
