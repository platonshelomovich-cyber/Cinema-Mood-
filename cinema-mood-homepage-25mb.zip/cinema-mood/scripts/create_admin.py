"""Create the first administrator without an unsafe public self-registration path."""
import getpass
from sqlalchemy import select
from app.db import Base, engine, SessionLocal
from app.models import User
from app.security import hash_secret

Base.metadata.create_all(engine)
email = input("Admin email: ").strip().lower()
username = input("Admin username: ").strip()
password = getpass.getpass("Admin password (10+ chars): ")
if len(password) < 10:
    raise SystemExit("Password must contain at least 10 characters")
with SessionLocal() as db:
    user = db.scalar(select(User).where(User.email == email))
    if user:
        user.is_admin = True
        user.password_hash = hash_secret(password)
    else:
        raise SystemExit("Create the account through the app first, then run this script to promote it.")
    db.commit()
print("Administrator access enabled.")
