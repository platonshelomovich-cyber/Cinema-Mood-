import json
from pathlib import Path
path = Path(__file__).resolve().parents[1] / "data" / "manual_pilot_films.json"
films = json.loads(path.read_text(encoding="utf-8"))
assert len(films) == 5
for film in films:
    for field in ("title_ru","release_year","director","cast","overview","runtime","watch_url","trailer_url","source_url","interesting_fact","fact_source_url","why_watch"):
        assert film.get(field), f"{film.get('title_ru')}: missing {field}"
    assert film["watch_url"].startswith("https://vkvideo.ru/")
    assert film["fact_source_url"].startswith("https://")
print(f"OK: {len(films)} cards; credits, links, interesting facts and watch recommendations present.")
