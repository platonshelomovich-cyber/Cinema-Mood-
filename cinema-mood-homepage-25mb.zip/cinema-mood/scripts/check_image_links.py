#!/usr/bin/env python3
"""Проверяет внешние изображения фильмов и сохраняет CSV-отчёт."""
import csv
import sqlite3
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / 'cinema_mood.db'
OUT = ROOT / 'data' / 'image_link_check.csv'


def check(row):
    film_id, title, year, url = row
    if not url:
        return [film_id, title, year, '', 'НЕТ ССЫЛКИ', '']
    req = Request(url, headers={'User-Agent': 'Mozilla/5.0 (compatible; CinemaMoodImageCheck/1.0)'}, method='GET')
    try:
        with urlopen(req, timeout=8) as response:
            content_type = response.headers.get('Content-Type', '').split(';')[0]
            status = response.status
            # Читаем небольшой фрагмент, чтобы отличить картинку от HTML-страницы.
            sample = response.read(512)
            is_image = content_type.startswith('image/') or sample.startswith((b'\xff\xd8\xff', b'\x89PNG', b'GIF8', b'RIFF'))
            result = 'РАБОТАЕТ' if 200 <= status < 300 and is_image else 'ПРОВЕРИТЬ'
            return [film_id, title, year, url, result, f'HTTP {status}; {content_type}']
    except HTTPError as e:
        return [film_id, title, year, url, 'НЕ РАБОТАЕТ', f'HTTP {e.code}']
    except (URLError, TimeoutError, OSError) as e:
        return [film_id, title, year, url, 'ОШИБКА СЕТИ', str(e)[:180]]


def main():
    if not DB.exists():
        print(f'Не найдена база: {DB}')
        sys.exit(1)
    con = sqlite3.connect(DB)
    rows = con.execute('SELECT id, title_ru, release_year, poster_path FROM films ORDER BY id').fetchall()
    con.close()
    results = []
    with ThreadPoolExecutor(max_workers=8) as pool:
        futures = [pool.submit(check, row) for row in rows]
        for future in as_completed(futures):
            results.append(future.result())
    results.sort(key=lambda x: x[0])
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with OUT.open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f, delimiter=';')
        writer.writerow(['ID', 'Фильм', 'Год', 'URL', 'Результат', 'Подробности'])
        writer.writerows(results)
    good = sum(x[4] == 'РАБОТАЕТ' for x in results)
    print(f'Проверено: {len(results)}; изображения доступны: {good}; требуют внимания: {len(results)-good}')
    print(f'Отчёт: {OUT}')
    print('Статусы «ОШИБКА СЕТИ» могут означать временную блокировку или отсутствие интернета, а не битую ссылку.')

if __name__ == '__main__':
    main()
