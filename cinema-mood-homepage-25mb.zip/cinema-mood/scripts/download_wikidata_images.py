#!/usr/bin/env python3
"""Download source images linked by Wikidata P18 for imported films.
Run after scripts/import_wikidata_900.py in an internet-enabled environment.
Only verified image bytes are saved; failed records keep their source URL. Every Wikidata P18 image is labelled 'Кадр из фильма' because it is not guaranteed to be an official theatrical poster.
Images are associated with the film via Wikidata P18, but may be a still/photo,
not necessarily an official theatrical poster; verify Commons license before publication.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import re, sqlite3
from PIL import Image
import httpx
ROOT=Path(__file__).resolve().parents[1]
DB=ROOT/'cinema_mood.db'; OUT=ROOT/'app/static/posters'; OUT.mkdir(parents=True,exist_ok=True)
HEADERS={'User-Agent':'CinemaMood/1.0 (Wikimedia Commons image fetcher)'}
MIME_EXT={'image/jpeg':'.jpg','image/png':'.png','image/webp':'.webp'}
def fetch(row):
    fid,title,url=row
    try:
        with httpx.Client(timeout=25,follow_redirects=True,headers=HEADERS) as client:
            r=client.get(url); r.raise_for_status()
        mime=r.headers.get('content-type','').split(';')[0].lower(); body=r.content
        valid=(mime=='image/jpeg' and body.startswith(b'\xff\xd8\xff')) or (mime=='image/png' and body.startswith(b'\x89PNG\r\n\x1a\n')) or (mime=='image/webp' and body[:4]==b'RIFF' and body[8:12]==b'WEBP')
        if not valid or len(body)<256 or len(body)>15*1024*1024: raise ValueError('invalid image payload')
        from io import BytesIO
        with Image.open(BytesIO(body)) as im:
            im.verify()
        with Image.open(BytesIO(body)) as im:
            if im.width < 180 or im.height < 240: raise ValueError('image dimensions too small')
        slug=re.sub(r'[^a-z0-9]+','-',title.lower()).strip('-')[:55] or 'film'
        name=f'wikidata-{abs(fid)}-{slug}{MIME_EXT[mime]}'; tmp=OUT/(name+'.part'); tmp.write_bytes(body); tmp.replace(OUT/name)
        return fid,f'/static/posters/{name}',None
    except Exception as e: return fid,None,str(e)
con=sqlite3.connect(DB)
rows=con.execute("SELECT id,title_original,poster_path FROM films WHERE image_kind IN ('poster','still') AND poster_path LIKE 'http%'").fetchall()
saved=failed=0
with ThreadPoolExecutor(max_workers=6) as pool:
    for f in as_completed([pool.submit(fetch,r) for r in rows]):
        fid,path,error=f.result()
        if path:
            con.execute("UPDATE films SET poster_path=? WHERE id=?",(path,fid)); saved+=1
        else:
            failed+=1; print(f'KEEP SOURCE URL for {fid}: {error}')
con.commit(); con.close()
print(f'Downloaded {saved}; failed {failed}; checked {len(rows)} source images.')
