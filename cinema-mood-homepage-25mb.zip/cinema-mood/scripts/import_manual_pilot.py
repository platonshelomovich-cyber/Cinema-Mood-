import json, sqlite3
from datetime import datetime, timezone
from pathlib import Path
from hashlib import sha256
root=Path(__file__).resolve().parents[1]
films=json.loads((root/'data/manual_pilot_films.json').read_text(encoding='utf-8'))
con=sqlite3.connect(root/'cinema_mood.db')
inserted=0
for f in films:
    # Stable negative IDs keep manual-source records distinct from TMDB IDs.
    tmdb_id = -int(sha256(f['source_id'].encode()).hexdigest()[:8],16)
    exists=con.execute('SELECT id FROM films WHERE tmdb_id=?',(tmdb_id,)).fetchone()
    if exists: continue
    con.execute('''INSERT INTO films
      (tmdb_id,title_ru,title_original,release_year,countries,genres,rating,poster_path,overview,runtime,director,cast,age_rating,oscar_wins,oscar_nominations,oscar_years,category,popularity,created_at,watch_url,trailer_url,source_url,interesting_fact,fact_source_url,why_watch)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
      (tmdb_id,f['title_ru'],f.get('title_original',''),f['release_year'],json.dumps(f.get('countries',[]),ensure_ascii=False),json.dumps(f.get('genres',[]),ensure_ascii=False),float(f['rating']),None,f.get('overview',''),f.get('runtime'),f.get('director',''),json.dumps(f.get('cast',[]),ensure_ascii=False),f.get('age_rating','NR'),0,0,'[]',f.get('category','soviet'),0.0,datetime.now(timezone.utc).isoformat(),f.get('watch_url'),f.get('trailer_url'),f.get('source_url'),f.get('interesting_fact',''),f.get('fact_source_url'),f.get('why_watch','')))
    inserted+=1
con.commit()
count=con.execute('SELECT COUNT(*) FROM films').fetchone()[0]
print(f'Inserted {inserted}; total films in database: {count}')
for row in con.execute('SELECT title_ru,release_year,director FROM films ORDER BY id'):
 print(*row,sep=' | ')
con.close()
