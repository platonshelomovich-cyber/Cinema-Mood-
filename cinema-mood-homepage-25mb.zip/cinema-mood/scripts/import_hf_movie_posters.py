#!/usr/bin/env python3
"""Import the full public movie metadata/poster-URL index as auxiliary data.

The source has ~804k rows and contains metadata + TMDB image URLs, NOT image
binaries. All rows go into film_reference_index (not the curated public/member
catalog). Exact title/year matches can additionally download poster files for
films already in Cinema Mood.

Run from project root:
  python scripts/import_hf_movie_posters.py --import-all
  python scripts/import_hf_movie_posters.py --download-matches --limit 1000
"""
from __future__ import annotations
import argparse, json, re, sqlite3, sys, time
from io import BytesIO
from pathlib import Path
import requests
import pyarrow.parquet as pq
from PIL import Image

DATASET_URL = "https://huggingface.co/datasets/ROSCOSMOS/Movie-Poster-WebURL-Dataset-1874-2025/resolve/main/train.parquet"
DATASET_INFO = "https://huggingface.co/datasets/ROSCOSMOS/Movie-Poster-WebURL-Dataset-1874-2025"
HEADERS = {"User-Agent": "CinemaMood/1.0 (metadata import; poster matching)"}


def norm(value: str | None) -> str:
    value = (value or "").casefold().replace("&", " and ")
    value = re.sub(r"[^a-z0-9а-яё]+", " ", value, flags=re.I)
    return " ".join(value.split())


def ensure_tables(con: sqlite3.Connection) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS film_reference_index (
      tmdb_id INTEGER PRIMARY KEY, title TEXT NOT NULL, release_date TEXT,
      release_year INTEGER, web_url TEXT, genres_json TEXT, keywords_json TEXT,
      runtime_minutes INTEGER, director_json TEXT, writer_json TEXT,
      top_cast_json TEXT, original_language TEXT, overview TEXT, tagline TEXT,
      tmdb_movie_url TEXT, title_norm TEXT
    )""")
    con.execute("CREATE INDEX IF NOT EXISTS idx_film_ref_title_year ON film_reference_index(title_norm, release_year)")
    cols = {r[1] for r in con.execute("PRAGMA table_info(films)")}
    if "image_source_url" not in cols:
        con.execute("ALTER TABLE films ADD COLUMN image_source_url TEXT")


def fetch_index(path: Path, timeout: int, refresh: bool) -> None:
    if path.exists() and not refresh:
        print(f"Using cached index: {path} ({path.stat().st_size:,} bytes)", flush=True)
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".part")
    print("Downloading source Parquet index (about 191 MB)…", flush=True)
    with requests.get(DATASET_URL, headers=HEADERS, stream=True, timeout=timeout) as r:
        r.raise_for_status()
        with tmp.open("wb") as f:
            for chunk in r.iter_content(1024 * 1024):
                if chunk:
                    f.write(chunk)
    tmp.replace(path)


def import_all_metadata(con: sqlite3.Connection, parquet_path: Path, batch_size: int) -> int:
    pf = pq.ParquetFile(parquet_path)
    total = 0
    sql = """INSERT OR REPLACE INTO film_reference_index
      (tmdb_id,title,release_date,release_year,web_url,genres_json,keywords_json,
       runtime_minutes,director_json,writer_json,top_cast_json,original_language,
       overview,tagline,tmdb_movie_url,title_norm)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"""
    cols = ["tmdb_id","title","release_date","release_year","web_url","genres",
            "keywords","runtime_minutes","director","writer","top_cast",
            "original_language","overview","tagline","tmdb_movie_url"]
    for batch in pf.iter_batches(batch_size=batch_size, columns=cols):
        rows = []
        data = batch.to_pydict()
        for i in range(batch.num_rows):
            get = lambda k: data[k][i]
            rows.append((get("tmdb_id"), get("title") or "", str(get("release_date")) if get("release_date") else None,
                get("release_year"), get("web_url"), json.dumps(get("genres") or [], ensure_ascii=False),
                json.dumps(get("keywords") or [], ensure_ascii=False), get("runtime_minutes"),
                json.dumps(get("director") or [], ensure_ascii=False), json.dumps(get("writer") or [], ensure_ascii=False),
                json.dumps(get("top_cast") or [], ensure_ascii=False), get("original_language"), get("overview"),
                get("tagline"), get("tmdb_movie_url"), norm(get("title"))))
        con.executemany(sql, rows)
        con.commit()
        total += len(rows)
        if total % 25000 < len(rows):
            print(f"Auxiliary metadata imported: {total:,}/{pf.metadata.num_rows:,}", flush=True)
    return total


def download_matched_posters(con: sqlite3.Connection, root: Path, limit: int, timeout: int, pause: float) -> tuple[int,int,int]:
    films = con.execute("SELECT id,title_original,title_ru,release_year,poster_path FROM films ORDER BY id").fetchall()
    session = requests.Session(); session.headers.update(HEADERS)
    poster_dir = root / "app" / "static" / "posters"; poster_dir.mkdir(parents=True, exist_ok=True)
    matched = downloaded = failed = 0
    for film in films:
        if downloaded >= limit: break
        if film[4] and str(film[4]).strip():
            continue
        candidates = [norm(film[1]), norm(film[2])]
        url = None
        for title in candidates:
            if not title: continue
            row = con.execute("SELECT web_url FROM film_reference_index WHERE title_norm=? AND release_year=? AND web_url LIKE 'https://image.tmdb.org/%' LIMIT 1",
                              (title, film[3])).fetchone()
            if row:
                url = row[0]; break
        if not url: continue
        matched += 1
        try:
            r = session.get(url, timeout=timeout); r.raise_for_status()
            if not 8000 <= len(r.content) <= 12_000_000: raise ValueError("image size outside accepted range")
            im = Image.open(BytesIO(r.content)); im.verify()
            im = Image.open(BytesIO(r.content)).convert("RGB")
            if im.width < 180 or im.height < 250: raise ValueError("image too small")
            name = f"{film[0]:04d}-tmdb-poster.jpg"; target = poster_dir / name
            im.save(target, "JPEG", quality=92, optimize=True)
            con.execute("UPDATE films SET poster_path=?, image_kind='poster', image_source_url=? WHERE id=?",
                        (f"/static/posters/{name}", url, film[0]))
            downloaded += 1
            if downloaded % 25 == 0: con.commit(); print(f"Posters downloaded: {downloaded}; matched: {matched}; failed: {failed}", flush=True)
        except Exception as e:
            failed += 1; print(f"SKIP {film[1]} ({film[3]}): {e}", file=sys.stderr)
        time.sleep(pause)
    con.commit()
    return matched, downloaded, failed


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default="cinema_mood.db")
    ap.add_argument("--import-all", action="store_true", help="Import all ~804k metadata rows into auxiliary index")
    ap.add_argument("--download-matches", action="store_true", help="Download exact title/year posters for existing catalog films")
    ap.add_argument("--limit", type=int, default=1000)
    ap.add_argument("--timeout", type=int, default=30)
    ap.add_argument("--pause", type=float, default=0.15)
    ap.add_argument("--batch-size", type=int, default=5000)
    ap.add_argument("--refresh-index", action="store_true")
    args = ap.parse_args()
    if not args.import_all and not args.download_matches:
        ap.error("Choose --import-all and/or --download-matches")
    root = Path(__file__).resolve().parents[1]
    db = Path(args.db); db = db if db.is_absolute() else root / db
    cache = root / "data" / "movie-poster-weburl-index.parquet"
    fetch_index(cache, args.timeout, args.refresh_index)
    con = sqlite3.connect(db); ensure_tables(con)
    if args.import_all:
        count = import_all_metadata(con, cache, args.batch_size)
        print(f"AUXILIARY IMPORT COMPLETE: {count:,} rows in film_reference_index", flush=True)
    if args.download_matches:
        matched, downloaded, failed = download_matched_posters(con, root, args.limit, args.timeout, args.pause)
        print(f"POSTER RESULT: matched={matched}, downloaded={downloaded}, failed={failed}", flush=True)
    con.close()
    print(f"Source: {DATASET_INFO}")

if __name__ == "__main__": main()
