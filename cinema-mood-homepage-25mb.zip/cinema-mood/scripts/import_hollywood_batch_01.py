"""Import the first curated 40-film Hollywood batch; safe to rerun."""
import json, sqlite3, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
films=json.loads((ROOT/'data/hollywood_batch_01.json').read_text(encoding='utf-8'))
con=sqlite3.connect(ROOT/'cinema_mood.db')
inserted=0
for f in films:
    tmdb_id=-int(hashlib.sha256(f['source_id'].encode()).hexdigest()[:8],16)
    if con.execute('SELECT 1 FROM films WHERE tmdb_id=?',(tmdb_id,)).fetchone(): continue
    values=(tmdb_id,f['title_ru'],f['title_original'],f['release_year'],json.dumps(['US'],ensure_ascii=False),json.dumps(f.get('genres',[]),ensure_ascii=False),float(f['rating']),None,f.get('overview',''),None,f.get('director',''), '[]','NR',0,0,'[]','hollywood',0.0,'2026-11-06T20:47:00+03:00',None,None,'https://www.imdb.com/chart/top/',f.get('interesting_fact',''),None,f.get('why_watch',''))
    con.execute('''INSERT INTO films (tmdb_id,title_ru,title_original,release_year,countries,genres,rating,poster_path,overview,runtime,director,cast,age_rating,oscar_wins,oscar_nominations,oscar_years,category,popularity,created_at,watch_url,trailer_url,source_url,interesting_fact,fact_source_url,why_watch) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',values)
    inserted+=1
con.commit()
print(f'Inserted {inserted}; Hollywood batch: {len(films)}; total: {con.execute("SELECT COUNT(*) FROM films").fetchone()[0]}')
con.close()
