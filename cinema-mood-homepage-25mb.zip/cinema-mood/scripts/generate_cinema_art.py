#!/usr/bin/env python3
"""Create original, title-specific Cinema Mood artwork (not official film posters)."""
from pathlib import Path
import argparse, hashlib, json, math, sqlite3
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / 'cinema_mood.db'
OUT = ROOT / 'app' / 'static' / 'posters'
W, H = 360, 540
FONTS = [Path('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'), Path('/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf')]
FONT_REG = [Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'), Path('/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf')]

def font(size, bold=True):
    for p in (FONTS if bold else FONT_REG):
        if p.exists(): return ImageFont.truetype(str(p), size)
    return ImageFont.load_default()

def seed_for(s): return int(hashlib.sha256(s.encode('utf-8')).hexdigest()[:16], 16)

def wrap(draw, text, fnt, maxw):
    words = str(text).split(); lines=[]; line=''
    for word in words:
        test=(line+' '+word).strip()
        if draw.textbbox((0,0),test,font=fnt)[2] <= maxw: line=test
        else:
            if line: lines.append(line)
            line=word
    if line: lines.append(line)
    return lines

def make_art(title, year, genres, film_id, outpath):
    seed=seed_for(f'{film_id}|{title}|{year}|{genres}')
    import random
    rng=random.Random(seed)
    genre=' '.join(genres).lower()
    palettes = [((8,18,35),(22,91,115),(244,166,82)),((34,12,20),(125,39,48),(245,166,104)),((9,30,25),(22,104,80),(208,199,126)),((18,15,42),(83,56,139),(235,158,211)),((28,21,13),(131,73,31),(246,190,96)),((10,25,42),(34,82,128),(145,206,225))]
    idx=seed%len(palettes)
    if any(x in genre for x in ('ужас','horror','триллер','thriller')): idx=1
    elif any(x in genre for x in ('фантаст','sci-fi','science fiction')): idx=3
    elif any(x in genre for x in ('романт','мелодрам','romance')): idx=4
    elif any(x in genre for x in ('приключ','adventure','фэнтези','fantasy')): idx=5
    elif any(x in genre for x in ('документ','documentary')): idx=2
    top,bottom,accent=palettes[idx]
    import numpy as np
    a=np.array(top,dtype=np.float32); b=np.array(bottom,dtype=np.float32)
    grad=np.linspace(0,1,H,dtype=np.float32)[:,None,None]
    arr=(a[None,None,:]*(1-grad)+b[None,None,:]*grad)
    arr=np.repeat(arr.astype('uint8'),W,axis=1)
    im=Image.fromarray(arr,'RGB')
    im=im.convert('RGBA')
    d=ImageDraw.Draw(im,'RGBA')
    cx=rng.randint(100,W-80); cy=rng.randint(120,H-180); rad=rng.randint(70,130)
    d.ellipse((cx-rad,cy-rad,cx+rad,cy+rad),fill=(*accent,85),outline=(*accent,190),width=3)
    # cinematic horizon / environment motif
    horizon=rng.randint(250,360)
    d.rectangle((0,horizon,W,H),fill=(0,0,0,65))
    # layered mountain/city skyline silhouettes
    pts=[(0,horizon)]
    x=0
    while x<=W:
        y=horizon-rng.randint(10,190)
        pts.append((x,y)); x+=rng.randint(35,90)
    pts += [(W,H),(0,H)]
    d.polygon(pts,fill=(3,7,13,115))
    # unique visual focal shapes
    motif=seed%5
    if motif==0: # planetary / sun
        r=rng.randint(60,110); x=rng.randint(110,260); y=rng.randint(210,470)
        d.ellipse((x-r,y-r,x+r,y+r),fill=(*accent,170),outline=(255,255,255,100),width=3)
        for k in range(4): d.arc((x-r-20-k*12,y-r-20-k*12,x+r+20+k*12,y+r+20+k*12),180,350,fill=(*accent,95),width=2)
    elif motif==1: # skyline
        x=0
        while x<W:
            bw=rng.randint(28,75); bh=rng.randint(60,190)
            d.rectangle((x,horizon-bh,x+bw,horizon),fill=(4,9,17,210))
            for wy in range(horizon-bh+12,horizon-8,25):
                for wx in range(x+8,x+bw-5,17): d.rectangle((wx,wy,wx+5,wy+8),fill=(*accent,110))
            x+=bw+rng.randint(4,12)
    elif motif==2: # ocean / wave bands
        for k in range(9):
            y=horizon+15+k*26; d.arc((-80,y-40,W+80,y+55),5,175,fill=(*accent,65+k*7),width=4)
    elif motif==3: # beams / geometric portal
        for k in range(3):
            pad=k*16
            d.rounded_rectangle((80+pad,170+pad,W-80-pad,horizon-20-pad//2),radius=16,outline=(*accent,max(25,150-k*16)),width=4)
    else: # abstract diagonal comet
        x=rng.randint(180,450); y=rng.randint(100,270)
        d.ellipse((x-55,y-55,x+55,y+55),fill=(*accent,200))
        d.polygon([(x-40,y+20),(0,horizon),(W,horizon),(x+35,y-20)],fill=(*accent,45))
    # subtle grain-like stars
    for _ in range(18):
        x=rng.randrange(W); y=rng.randrange(horizon)
        rr=rng.choice([1,1,2,3]); d.ellipse((x-rr,y-rr,x+rr,y+rr),fill=(255,255,255,rng.randint(15,85)))
    # frame and branding
    d.rectangle((28,28,W-28,H-28),outline=(255,224,180,170),width=3)
    d.text((52,58),'CINEMA MOOD',font=font(18),fill=(255,225,185,235))
    # title on a dark translucent plate
    plate_top=H-250
    d.rectangle((30,plate_top,W-30,H-30),fill=(0,0,0,115))
    titlefont=font(26)
    lines=wrap(d,title,titlefont,W-72)
    while max((d.textbbox((0,0),ln,font=titlefont)[2] for ln in lines),default=0)>W-72 and titlefont.size>16:
        titlefont=font(titlefont.size-2); lines=wrap(d,title,titlefont,W-72)
    y=plate_top+22
    for line in lines[:3]:
        d.text((52,y),line,font=titlefont,fill=(255,255,255,255),stroke_width=2,stroke_fill=(0,0,0,170)); y+=titlefont.size+7
    d.text((54,H-82),str(year or 'ГОД НЕ УКАЗАН'),font=font(17),fill=(255,207,144,245))
    d.text((54,H-53),'ОРИГИНАЛЬНАЯ ОБЛОЖКА',font=font(8),fill=(220,210,195,190))
    im.convert('RGB').save(outpath,'JPEG',quality=91,optimize=True)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--all',action='store_true'); args=ap.parse_args()
    OUT.mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(DB); con.row_factory=sqlite3.Row
    rows=con.execute('SELECT id,title_ru,title_original,release_year,genres,poster_path FROM films ORDER BY id').fetchall()
    done=0
    for r in rows:
        title=r['title_ru'] or r['title_original']
        if not args.all and r['poster_path'] and (ROOT/'app'/r['poster_path'].lstrip('/').replace('static/','static/')).exists(): continue
        name=f"{int(r['id']):04d}-cinema-mood-art.jpg"; path=OUT/name
        try: genres=json.loads(r['genres'] or '[]')
        except Exception: genres=[]
        make_art(title,r['release_year'],genres,r['id'],path)
        con.execute('UPDATE films SET poster_path=?, image_kind=? WHERE id=?',(f'/static/posters/{name}','artwork',r['id']))
        done+=1
    con.commit(); con.close(); print(f'Created/updated {done} artwork files for {len(rows)} films.')
if __name__=='__main__': main()
