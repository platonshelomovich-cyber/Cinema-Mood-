#!/usr/bin/env python3
"""Import up to 900 additional real feature films from Wikidata (no API key).
Run from the project root: PYTHONPATH=. python scripts/import_wikidata_900.py
Then run: python scripts/download_wikidata_images.py
Finally run: python scripts/generate_cinema_art.py
"""
from __future__ import annotations
import argparse, hashlib, re, sys, time
from datetime import datetime, timezone
from pathlib import Path
import httpx
from sqlalchemy import select, func
from app.db import SessionLocal
from app.models import Film

ENDPOINT = 'https://query.wikidata.org/sparql'
HEADERS = {'Accept':'application/sparql-results+json', 'User-Agent':'CinemaMoodCatalogImporter/1.0 (personal non-commercial project)'}
QUERY = '''SELECT ?film ?enLabel ?ruLabel ?year ?poster ?image ?directorLabel WHERE {
  ?film wdt:P31 wd:Q11424; wdt:P577 ?date.
  ?film rdfs:label ?enLabel. FILTER(LANG(?enLabel)="en")
  OPTIONAL { ?film rdfs:label ?ruLabel. FILTER(LANG(?ruLabel)="ru") }
  OPTIONAL { ?film wdt:P3383 ?poster. } # dedicated film-poster property
  OPTIONAL { ?film wdt:P18 ?image. } # representative image; treated as a film still, not a poster
  OPTIONAL { ?film wdt:P57 ?director. }
  OPTIONAL { ?director rdfs:label ?directorLabel. FILTER(LANG(?directorLabel)="en") }
  BIND(YEAR(?date) AS ?year)
  FILTER(?year >= 1888 && ?year <= 2025)
}
GROUP BY ?film ?enLabel ?ruLabel ?year ?poster ?image ?directorLabel
ORDER BY DESC(?year)
LIMIT 12000'''

def stable_id(qid: str, used: set[int]) -> int:
    n = -(int(hashlib.sha256(qid.encode()).hexdigest()[:7],16)+1)
    while n in used: n -= 1
    used.add(n); return n

def main():
    parser=argparse.ArgumentParser(description='Импорт до 900 дополнительных фильмов из Wikidata')
    parser.add_argument('--limit', type=int, default=900)
    args=parser.parse_args()
    target=max(1,min(args.limit,900))
    with httpx.Client(timeout=70, headers=HEADERS, follow_redirects=True) as client:
        response=client.get(ENDPOINT,params={'query':QUERY,'format':'json'})
        response.raise_for_status(); rows=response.json()['results']['bindings']
    db=SessionLocal()
    try:
        existing={x.lower() for x in db.scalars(select(Film.title_original)).all() if x}
        existing.update(x.lower() for x in db.scalars(select(Film.title_ru)).all() if x)
        used=set(db.scalars(select(Film.tmdb_id)).all())
        added=0; seen_qids=set()
        for row in rows:
            uri=row['film']['value']; qid=uri.rsplit('/',1)[-1]
            if qid in seen_qids: continue
            seen_qids.add(qid)
            original=row.get('enLabel',{}).get('value','').strip()
            russian=row.get('ruLabel',{}).get('value','').strip() or original
            try: year=int(row.get('year',{}).get('value','0'))
            except ValueError: continue
            if not original or not 1888 <= year <= 2025: continue
            if original.lower() in existing or russian.lower() in existing: continue
            director=row.get('directorLabel',{}).get('value','')
            poster_name=row.get('poster',{}).get('value','').rsplit('/',1)[-1]
            still_name=row.get('image',{}).get('value','').rsplit('/',1)[-1]
            selected_name=poster_name or still_name
            selected_kind='poster' if poster_name else ('still' if still_name else 'missing')
            image_url=('https://commons.wikimedia.org/wiki/Special:FilePath/' +
                       __import__('urllib.parse', fromlist=['quote']).quote(selected_name)) if selected_name else None
            film=Film(
                tmdb_id=stable_id(qid,used), title_ru=russian[:300], title_original=original[:300],
                release_year=year, countries=[], genres=[], rating=0.0, poster_path=image_url,
                image_kind=selected_kind, access_level='member', overview='Описание фильма ещё уточняется. Данные получены из Wikidata.',
                runtime=None, director=director[:300], cast=[], age_rating='NR', oscar_wins=0,
                oscar_nominations=0, oscar_years=[], category='world', popularity=0.0,
                source_url='https://www.wikidata.org/wiki/'+qid, interesting_fact='__metadata_pending__',
                why_watch='Карточка ожидает редакционной проверки.', created_at=datetime.now(timezone.utc).replace(tzinfo=None)
            )
            db.add(film); existing.add(original.lower()); existing.add(russian.lower()); added+=1
            if added >= target: break
        db.commit()
        print(f'Добавлено: {added}; всего фильмов: {db.scalar(select(func.count(Film.id)))}')
        if added < target: print(f'ВНИМАНИЕ: добавлено {added} из запрошенных {target}; источник мог вернуть меньше уникальных фильмов.')
    except Exception:
        db.rollback(); raise
    finally: db.close()

if __name__=='__main__': main()
