"""Fail-fast integrity audit for the curated 1,900-film catalogue."""
from sqlalchemy import select, func
from app.db import SessionLocal
from app.models import Film
EXPECTED={"hollywood":1300,"world":570,"soviet":30}
with SessionLocal() as db:
    total=db.scalar(select(func.count(Film.id))) or 0
    counts={k:db.scalar(select(func.count(Film.id)).where(Film.category==k)) or 0 for k in EXPECTED}
    ids=db.scalars(select(Film.tmdb_id)).all()
    incomplete=db.scalars(select(Film).where((Film.rating < 7.0) | (Film.rating > 10.0) | (Film.poster_path.is_(None)) | (Film.runtime.is_(None)) | (Film.overview == "") | (Film.director == "") | (Film.title_ru == "") | (Film.title_original == "") | (Film.age_rating == "NR"))).all()
    no_cast=db.scalars(select(Film).where(Film.cast.is_(None))).all()
    problems=[]
    if total != 1900: problems.append(f"total={total}, expected=1900")
    if counts != EXPECTED: problems.append(f"category counts={counts}, expected={EXPECTED}")
    if len(ids) != len(set(ids)): problems.append("duplicate TMDB IDs")
    if incomplete: problems.append(f"{len(incomplete)} films have missing/invalid required fields")
    if no_cast: problems.append(f"{len(no_cast)} films have no cast data")
    if problems: raise SystemExit("CATALOG INVALID: " + "; ".join(problems))
print("CATALOG VALID: exactly 1,900 unique records; category quotas and required fields passed.")
