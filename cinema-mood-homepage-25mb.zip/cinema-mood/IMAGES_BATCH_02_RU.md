# Партия изображений №2

В базе добавлены внешние ссылки на постеры для следующих фильмов:

- Семь (1995) — IMP Awards — Seven (1995), poster gallery https://www.impawards.com/1995/seven_ver1.html
- Звёздные войны: Эпизод 4 — Новая надежда (1977) — Original Film Art — Star Wars (1977) original one-sheet https://www.originalfilmart.com/products/star-wars
- Зелёная миля (1999) — eBay listing image — The Green Mile (1999) poster
- Пролетая над гнездом кукушки (1975) — IMDb media viewer — One Flew Over the Cuckoo’s Nest (1975) poster
- Эта замечательная жизнь (1946) — FilmAffinity — It’s a Wonderful Life (1946) poster https://www.filmaffinity.com/en/film682814.html
- Касабланка (1942) — Кинопоиск — постер «Касабланка» (1942)
- Тёмный рыцарь: Возрождение легенды (2012) — IMP Awards — The Dark Knight Rises (2012) poster https://www.impawards.com/2012/dark_knight_rises.html
- Сияние (1980) — FilmArt Gallery — The Shining (1980) poster https://filmartgallery.com/products/the-shining-3
- Индиана Джонс: В поисках утраченного ковчега (1981) — FilmArt Gallery — Raiders of the Lost Ark (1981) poster https://filmartgallery.com/products/raiders-of-the-lost-ark-6
- Чужой (1979) — Original Film Art — Alien (1979) poster https://www.originalfilmart.com/products/alien-79

Важно: это URL изображений, а не локально скачанные файлы. Для показа на сайте требуется доступность источника; рекомендуется позднее сохранить файлы локально и проверить права/условия использования.
